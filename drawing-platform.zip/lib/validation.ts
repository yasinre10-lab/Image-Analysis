import { z } from "zod"

// User validation schemas
export const userValidationSchema = z.object({
  displayName: z
    .string()
    .min(2, "Display name must be at least 2 characters")
    .max(50, "Display name must be less than 50 characters")
    .regex(/^[a-zA-Z0-9\u0600-\u06FF\s]+$/, "Display name contains invalid characters"),
  email: z.string().email("Invalid email address"),
  role: z.enum(["user", "admin"], { required_error: "Role is required" }),
  status: z.enum(["active", "banned"], { required_error: "Status is required" }),
})

// Artwork validation schemas
export const artworkValidationSchema = z.object({
  title: z
    .string()
    .min(1, "Title is required")
    .max(100, "Title must be less than 100 characters")
    .regex(/^[a-zA-Z0-9\u0600-\u06FF\s\-_.,!?]+$/, "Title contains invalid characters"),
  description: z.string().max(500, "Description must be less than 500 characters").optional(),
  tags: z.array(z.string().min(1).max(20)).max(10, "Maximum 10 tags allowed").optional(),
  featured: z.boolean(),
  status: z.enum(["active", "hidden", "reported"]),
})

// Tool validation schemas
export const toolValidationSchema = z.object({
  name: z
    .string()
    .min(2, "Tool name must be at least 2 characters")
    .max(30, "Tool name must be less than 30 characters"),
  nameAr: z
    .string()
    .min(2, "Arabic name must be at least 2 characters")
    .max(30, "Arabic name must be less than 30 characters"),
  type: z.enum(["brush", "shape", "eraser", "fill", "eyedropper"]),
  enabled: z.boolean(),
  defaultSize: z.number().min(1).max(200),
  minSize: z.number().min(1).max(200),
  maxSize: z.number().min(1).max(200),
  defaultOpacity: z.number().min(1).max(100),
})

// Color palette validation schemas
export const colorPaletteValidationSchema = z.object({
  name: z
    .string()
    .min(2, "Palette name must be at least 2 characters")
    .max(50, "Palette name must be less than 50 characters"),
  nameAr: z
    .string()
    .min(2, "Arabic name must be at least 2 characters")
    .max(50, "Arabic name must be less than 50 characters"),
  colors: z
    .array(z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Invalid color format"))
    .min(1, "At least one color is required")
    .max(20, "Maximum 20 colors allowed"),
  category: z.enum(["basic", "artistic", "nature", "custom"]),
  enabled: z.boolean(),
  isDefault: z.boolean(),
})

// Site settings validation schemas
export const siteSettingsValidationSchema = z.object({
  siteName: z.string().min(1, "Site name is required").max(100),
  siteNameAr: z.string().min(1, "Arabic site name is required").max(100),
  siteDescription: z.string().max(500),
  siteDescriptionAr: z.string().max(500),
  siteUrl: z.string().url("Invalid URL format"),
  contactEmail: z.string().email("Invalid email address"),
  maxFileSize: z.number().min(1).max(100),
  maxCanvasSize: z.number().min(500).max(10000),
  maxLayersPerDrawing: z.number().min(1).max(100),
  maxDrawingsPerUser: z.number().min(1).max(10000),
  dataRetentionDays: z.number().min(30).max(3650),
  cacheTimeout: z.number().min(1).max(1440),
})

// Content moderation
export const bannedWordsRegex = (words: string[]) => {
  if (words.length === 0) return null
  const pattern = words.map((word) => word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")
  return new RegExp(`\\b(${pattern})\\b`, "gi")
}

// Sanitize HTML content
export const sanitizeHtml = (content: string): string => {
  return content
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "")
    .replace(/javascript:/gi, "")
    .replace(/on\w+\s*=/gi, "")
    .trim()
}

// Validate file uploads
export const validateFileUpload = (file: File, maxSize = 10): { valid: boolean; error?: string } => {
  const allowedTypes = ["image/png", "image/jpeg", "image/jpg", "image/gif"]
  const maxSizeBytes = maxSize * 1024 * 1024 // Convert MB to bytes

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: "Invalid file type. Only PNG, JPEG, JPG, and GIF are allowed." }
  }

  if (file.size > maxSizeBytes) {
    return { valid: false, error: `File size exceeds ${maxSize}MB limit.` }
  }

  return { valid: true }
}

// Rate limiting helper
export const createRateLimiter = (maxRequests: number, windowMs: number) => {
  const requests = new Map<string, number[]>()

  return (identifier: string): boolean => {
    const now = Date.now()
    const userRequests = requests.get(identifier) || []

    // Remove old requests outside the window
    const validRequests = userRequests.filter((time) => now - time < windowMs)

    if (validRequests.length >= maxRequests) {
      return false // Rate limit exceeded
    }

    validRequests.push(now)
    requests.set(identifier, validRequests)
    return true
  }
}
