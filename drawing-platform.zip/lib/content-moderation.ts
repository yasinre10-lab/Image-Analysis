import { bannedWordsRegex, sanitizeHtml } from "./validation"

export interface ModerationResult {
  approved: boolean
  confidence: number
  flags: string[]
  sanitizedContent?: string
}

export class ContentModerator {
  private bannedWords: string[] = []
  private suspiciousPatterns: RegExp[] = [
    /\b(?:https?:\/\/|www\.)\S+/gi, // URLs
    /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/gi, // Email addresses
    /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g, // Phone numbers
  ]

  setBannedWords(words: string[]): void {
    this.bannedWords = words
  }

  moderateText(content: string): ModerationResult {
    const flags: string[] = []
    let confidence = 1.0

    // Check for banned words
    const bannedWordsPattern = bannedWordsRegex(this.bannedWords)
    if (bannedWordsPattern && bannedWordsPattern.test(content)) {
      flags.push("banned_words")
      confidence -= 0.8
    }

    // Check for suspicious patterns
    for (const pattern of this.suspiciousPatterns) {
      if (pattern.test(content)) {
        flags.push("suspicious_content")
        confidence -= 0.3
        break
      }
    }

    // Check for excessive capitalization
    const capsRatio = (content.match(/[A-Z]/g) || []).length / content.length
    if (capsRatio > 0.7 && content.length > 10) {
      flags.push("excessive_caps")
      confidence -= 0.2
    }

    // Check for repeated characters
    if (/(.)\1{4,}/.test(content)) {
      flags.push("spam_pattern")
      confidence -= 0.3
    }

    // Sanitize content
    const sanitizedContent = sanitizeHtml(content)

    return {
      approved: confidence > 0.5 && flags.length === 0,
      confidence: Math.max(0, confidence),
      flags,
      sanitizedContent,
    }
  }

  moderateImage(imageData: string | File): Promise<ModerationResult> {
    // In a real implementation, this would use an image moderation service
    // like Google Cloud Vision API, AWS Rekognition, or Azure Content Moderator
    return Promise.resolve({
      approved: true,
      confidence: 0.9,
      flags: [],
    })
  }

  async moderateArtwork(title: string, description: string, imageData?: string | File): Promise<ModerationResult> {
    const titleResult = this.moderateText(title)
    const descriptionResult = this.moderateText(description)

    let imageResult: ModerationResult = { approved: true, confidence: 1.0, flags: [] }
    if (imageData) {
      imageResult = await this.moderateImage(imageData)
    }

    const overallConfidence = (titleResult.confidence + descriptionResult.confidence + imageResult.confidence) / 3
    const allFlags = [...titleResult.flags, ...descriptionResult.flags, ...imageResult.flags]

    return {
      approved: titleResult.approved && descriptionResult.approved && imageResult.approved,
      confidence: overallConfidence,
      flags: [...new Set(allFlags)], // Remove duplicates
      sanitizedContent: JSON.stringify({
        title: titleResult.sanitizedContent,
        description: descriptionResult.sanitizedContent,
      }),
    }
  }
}

export const contentModerator = new ContentModerator()
