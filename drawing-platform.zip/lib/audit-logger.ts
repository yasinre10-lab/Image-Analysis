import { collection, addDoc, serverTimestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"

export interface AuditLogEntry {
  userId: string
  userEmail: string
  action: string
  resource: string
  resourceId?: string
  details?: Record<string, any>
  ipAddress?: string
  userAgent?: string
  timestamp: any
  severity: "low" | "medium" | "high" | "critical"
}

export class AuditLogger {
  private static instance: AuditLogger
  private logQueue: AuditLogEntry[] = []
  private isProcessing = false

  static getInstance(): AuditLogger {
    if (!AuditLogger.instance) {
      AuditLogger.instance = new AuditLogger()
    }
    return AuditLogger.instance
  }

  async log(entry: Omit<AuditLogEntry, "timestamp">): Promise<void> {
    const logEntry: AuditLogEntry = {
      ...entry,
      timestamp: serverTimestamp(),
    }

    this.logQueue.push(logEntry)

    if (!this.isProcessing) {
      this.processQueue()
    }
  }

  private async processQueue(): Promise<void> {
    this.isProcessing = true

    while (this.logQueue.length > 0) {
      const entry = this.logQueue.shift()
      if (entry) {
        try {
          await addDoc(collection(db, "audit-logs"), entry)
        } catch (error) {
          console.error("Failed to write audit log:", error)
          // In production, you might want to retry or use a fallback logging mechanism
        }
      }
    }

    this.isProcessing = false
  }

  // Predefined log methods for common actions
  async logUserAction(userId: string, userEmail: string, action: string, details?: Record<string, any>): Promise<void> {
    await this.log({
      userId,
      userEmail,
      action,
      resource: "user",
      details,
      severity: "medium",
    })
  }

  async logArtworkAction(
    userId: string,
    userEmail: string,
    action: string,
    artworkId: string,
    details?: Record<string, any>,
  ): Promise<void> {
    await this.log({
      userId,
      userEmail,
      action,
      resource: "artwork",
      resourceId: artworkId,
      details,
      severity: action.includes("delete") ? "high" : "medium",
    })
  }

  async logSecurityEvent(
    userId: string,
    userEmail: string,
    action: string,
    details?: Record<string, any>,
  ): Promise<void> {
    await this.log({
      userId,
      userEmail,
      action,
      resource: "security",
      details,
      severity: "critical",
    })
  }

  async logSettingsChange(
    userId: string,
    userEmail: string,
    setting: string,
    oldValue: any,
    newValue: any,
  ): Promise<void> {
    await this.log({
      userId,
      userEmail,
      action: "settings_update",
      resource: "settings",
      details: {
        setting,
        oldValue,
        newValue,
      },
      severity: "high",
    })
  }
}

export const auditLogger = AuditLogger.getInstance()
