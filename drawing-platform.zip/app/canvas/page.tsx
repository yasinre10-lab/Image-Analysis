import { ProtectedRoute } from "@/components/protected-route"
import { CanvasPage } from "@/components/canvas-page"

export default function Page() {
  return (
    <ProtectedRoute>
      <CanvasPage />
    </ProtectedRoute>
  )
}
