import { AuthPage } from "@/components/auth-page"

export default function Page() {
  return <AuthPage />
}
