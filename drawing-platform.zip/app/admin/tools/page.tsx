import { ToolManagement } from "@/components/tool-management"

export default function ToolsPage() {
  return <ToolManagement />
}
