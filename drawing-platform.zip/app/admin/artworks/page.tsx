import { ArtworkManagement } from "@/components/artwork-management"

export default function ArtworksPage() {
  return <ArtworkManagement />
}
