import { SecurityMonitor } from "@/components/security-monitor"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"

export default function SecurityPage() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <SecurityMonitor />
      </AdminLayout>
    </ProtectedRoute>
  )
}
