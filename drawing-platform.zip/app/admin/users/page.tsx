import { UserManagement } from "@/components/user-management"

export default function UsersPage() {
  return <UserManagement />
}
