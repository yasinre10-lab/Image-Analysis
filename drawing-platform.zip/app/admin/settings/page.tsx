import { SiteSettings } from "@/components/site-settings"

export default function SettingsPage() {
  return <SiteSettings />
}
