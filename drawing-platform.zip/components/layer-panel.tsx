"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { X, Plus, Trash2, Eye, EyeOff, ChevronUp, ChevronDown, Edit3 } from "lucide-react"

interface Layer {
  id: string
  name: string
  visible: boolean
  opacity: number
  canvas: HTMLCanvasElement
}

interface LayerPanelProps {
  layers: Layer[]
  activeLayerId: string
  onLayerChange: (layers: Layer[]) => void
  onActiveLayerChange: (layerId: string) => void
  onClose: () => void
}

export function LayerPanel({ layers, activeLayerId, onLayerChange, onActiveLayerChange, onClose }: LayerPanelProps) {
  const [editingLayerId, setEditingLayerId] = useState<string | null>(null)
  const [editingName, setEditingName] = useState("")

  const addLayer = () => {
    const newLayer: Layer = {
      id: `layer-${Date.now()}`,
      name: `Layer ${layers.length + 1}`,
      visible: true,
      opacity: 1,
      canvas: document.createElement("canvas"),
    }

    onLayerChange([...layers, newLayer])
    onActiveLayerChange(newLayer.id)
  }

  const deleteLayer = (layerId: string) => {
    if (layers.length <= 1) return // Keep at least one layer

    const newLayers = layers.filter((layer) => layer.id !== layerId)
    onLayerChange(newLayers)

    if (activeLayerId === layerId) {
      onActiveLayerChange(newLayers[0]?.id || "")
    }
  }

  const toggleLayerVisibility = (layerId: string) => {
    const newLayers = layers.map((layer) => (layer.id === layerId ? { ...layer, visible: !layer.visible } : layer))
    onLayerChange(newLayers)
  }

  const updateLayerOpacity = (layerId: string, opacity: number) => {
    const newLayers = layers.map((layer) => (layer.id === layerId ? { ...layer, opacity: opacity / 100 } : layer))
    onLayerChange(newLayers)
  }

  const moveLayer = (layerId: string, direction: "up" | "down") => {
    const currentIndex = layers.findIndex((layer) => layer.id === layerId)
    if (currentIndex === -1) return

    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1
    if (newIndex < 0 || newIndex >= layers.length) return

    const newLayers = [...layers]
    const [movedLayer] = newLayers.splice(currentIndex, 1)
    newLayers.splice(newIndex, 0, movedLayer)

    onLayerChange(newLayers)
  }

  const startEditingName = (layer: Layer) => {
    setEditingLayerId(layer.id)
    setEditingName(layer.name)
  }

  const finishEditingName = () => {
    if (editingLayerId && editingName.trim()) {
      const newLayers = layers.map((layer) =>
        layer.id === editingLayerId ? { ...layer, name: editingName.trim() } : layer,
      )
      onLayerChange(newLayers)
    }
    setEditingLayerId(null)
    setEditingName("")
  }

  return (
    <Card className="w-80 bg-background/95 backdrop-blur">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">الطبقات | Layers</CardTitle>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={addLayer}>
            <Plus className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-2 max-h-96 overflow-y-auto">
        {layers.map((layer, index) => (
          <div
            key={layer.id}
            className={`p-3 rounded border-2 transition-colors ${
              layer.id === activeLayerId ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
            }`}
          >
            {/* Layer Header */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 flex-1">
                {editingLayerId === layer.id ? (
                  <Input
                    value={editingName}
                    onChange={(e) => setEditingName(e.target.value)}
                    onBlur={finishEditingName}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") finishEditingName()
                      if (e.key === "Escape") {
                        setEditingLayerId(null)
                        setEditingName("")
                      }
                    }}
                    className="h-6 text-xs"
                    autoFocus
                  />
                ) : (
                  <span
                    className="text-sm font-medium cursor-pointer hover:text-primary flex-1"
                    onClick={() => onActiveLayerChange(layer.id)}
                    onDoubleClick={() => startEditingName(layer)}
                  >
                    {layer.name}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => startEditingName(layer)}>
                  <Edit3 className="h-3 w-3" />
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                  onClick={() => toggleLayerVisibility(layer.id)}
                >
                  {layer.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3 opacity-50" />}
                </Button>

                {layers.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                    onClick={() => deleteLayer(layer.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>

            {/* Layer Controls */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  الشفافية | Opacity: {Math.round(layer.opacity * 100)}%
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => moveLayer(layer.id, "up")}
                    disabled={index === 0}
                  >
                    <ChevronUp className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => moveLayer(layer.id, "down")}
                    disabled={index === layers.length - 1}
                  >
                    <ChevronDown className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <Slider
                value={[layer.opacity * 100]}
                onValueChange={([opacity]) => updateLayerOpacity(layer.id, opacity)}
                min={0}
                max={100}
                step={1}
                className="w-full"
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
