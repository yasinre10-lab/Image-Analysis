"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useLanguage } from "@/components/language-provider"
import { LanguageToggle } from "@/components/language-toggle"
import { ThemeToggle } from "@/components/theme-toggle"
import { Palette, Layers, Undo2, Brush, Zap, Users, Star, ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"
import { UserMenu } from "@/components/user-menu"

export function HomePage() {
  const { t } = useLanguage()

  const features = [
    {
      icon: Brush,
      title: t("drawing.brush"),
      description: "أدوات رسم متقدمة مع دعم الضغط واللمس | Advanced brush tools with pressure and touch support",
    },
    {
      icon: Layers,
      title: t("drawing.layers"),
      description: "نظام طبقات متقدم لتنظيم أعمالك الفنية | Advanced layer system for organizing your artwork",
    },
    {
      icon: Palette,
      title: t("drawing.color"),
      description: "أداة اختيار الألوان مع دعم HSL/RGB/HEX | Color picker with HSL/RGB/HEX support",
    },
    {
      icon: Undo2,
      title: "تراجع وإعادة | Undo/Redo",
      description: "تراجع وإعادة غير محدود لحرية الإبداع | Unlimited undo/redo for creative freedom",
    },
    {
      icon: Zap,
      title: "أداء سريع | Fast Performance",
      description: "محرك رسم محسن للأداء السريع | Optimized drawing engine for fast performance",
    },
    {
      icon: Users,
      title: "متعدد المستخدمين | Multi-user",
      description: "دعم متعدد المستخدمين مع لوحة تحكم | Multi-user support with admin dashboard",
    },
  ]

  const galleryItems = [
    {
      title: "رسم رقمي | Digital Art",
      image: "/placeholder-pmjcg.png",
      artist: "فنان مجهول | Anonymous Artist",
    },
    {
      title: "رسم بالألوان المائية | Watercolor",
      image: "/placeholder-sx4xj.png",
      artist: "سارة أحمد | Sarah Ahmed",
    },
    {
      title: "رسم بالقلم الرصاص | Pencil Drawing",
      image: "/realistic-pencil-portrait.png",
      artist: "محمد علي | Mohammed Ali",
    },
    {
      title: "فن تجريدي | Abstract Art",
      image: "/abstract-geometric-shapes-colorful-modern.png",
      artist: "ليلى حسن | Layla Hassan",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Palette className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold gradient-text">{t("homepage.title")}</span>
          </div>

          <div className="flex items-center gap-2">
            <LanguageToggle />
            <ThemeToggle />
            <UserMenu />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 gradient-bg opacity-10"></div>
        <div className="container relative px-4">
          <div className="mx-auto max-w-4xl text-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl font-bold tracking-tight sm:text-6xl md:text-7xl">
                <span className="gradient-text">{t("homepage.title")}</span>
              </h1>
              <p className="mt-6 text-lg leading-8 text-muted-foreground sm:text-xl">{t("homepage.subtitle")}</p>

              <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:justify-center">
                <Link href="/draw">
                  <Button size="lg" className="group gap-2 text-lg px-8 py-6">
                    <Sparkles className="h-5 w-5 transition-transform group-hover:scale-110" />
                    {t("homepage.startDrawing")}
                    <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>

                <Link href="/auth">
                  <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                    {t("homepage.register")}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">{t("homepage.features")}</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              اكتشف الأدوات المتقدمة التي تجعل من الرسم تجربة استثنائية
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-lg">{feature.title}</h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20">
        <div className="container px-4">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">{t("homepage.gallery")}</h2>
            <p className="mt-4 text-lg text-muted-foreground">استكشف الأعمال الفنية المذهلة التي أنشأها مستخدمونا</p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {galleryItems.map((item, index) => (
              <Card
                key={index}
                className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    {item.artist}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-6">ابدأ رحلتك الفنية اليوم</h2>
            <p className="text-lg text-muted-foreground mb-8">انضم إلى آلاف الفنانين واكتشف إمكانياتك الإبداعية</p>
            <Link href="/draw">
              <Button size="lg" className="group gap-2 text-lg px-8 py-6">
                <Palette className="h-5 w-5 transition-transform group-hover:rotate-12" />
                {t("homepage.startDrawing")}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container px-4">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div className="flex items-center gap-2">
              <Palette className="h-6 w-6 text-primary" />
              <span className="font-semibold">{t("homepage.title")}</span>
            </div>
            <p className="text-sm text-muted-foreground">© 2024 منصة الرسم الاحترافية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
