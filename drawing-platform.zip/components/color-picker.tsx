"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { X, Pipette } from "lucide-react"

interface ColorPickerProps {
  color: string
  onChange: (color: string) => void
  onClose: () => void
}

export function ColorPicker({ color, onChange, onClose }: ColorPickerProps) {
  const [hue, setHue] = useState(0)
  const [saturation, setSaturation] = useState(100)
  const [lightness, setLightness] = useState(50)
  const [hexInput, setHexInput] = useState(color)

  const presetColors = [
    "#000000",
    "#FFFFFF",
    "#FF0000",
    "#00FF00",
    "#0000FF",
    "#FFFF00",
    "#FF00FF",
    "#00FFFF",
    "#FFA500",
    "#800080",
    "#FFC0CB",
    "#A52A2A",
    "#808080",
    "#000080",
    "#008000",
  ]

  const hslToHex = (h: number, s: number, l: number) => {
    l /= 100
    const a = (s * Math.min(l, 1 - l)) / 100
    const f = (n: number) => {
      const k = (n + h / 30) % 12
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
      return Math.round(255 * color)
        .toString(16)
        .padStart(2, "0")
    }
    return `#${f(0)}${f(8)}${f(4)}`
  }

  const updateFromHSL = () => {
    const newColor = hslToHex(hue, saturation, lightness)
    onChange(newColor)
    setHexInput(newColor)
  }

  const handleHexChange = (hex: string) => {
    setHexInput(hex)
    if (/^#[0-9A-F]{6}$/i.test(hex)) {
      onChange(hex)
    }
  }

  return (
    <Card className="w-80 bg-background/95 backdrop-blur">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">اختيار اللون | Color Picker</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Color Preview */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded border-2 border-border" style={{ backgroundColor: color }} />
          <div className="flex-1">
            <Label htmlFor="hex" className="text-xs">
              HEX
            </Label>
            <Input
              id="hex"
              value={hexInput}
              onChange={(e) => handleHexChange(e.target.value)}
              className="h-8 text-sm"
              placeholder="#000000"
            />
          </div>
        </div>

        {/* HSL Sliders */}
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Hue: {hue}°</Label>
            <Slider
              value={[hue]}
              onValueChange={([value]) => {
                setHue(value)
                updateFromHSL()
              }}
              min={0}
              max={360}
              step={1}
              className="w-full"
            />
          </div>

          <div>
            <Label className="text-xs">Saturation: {saturation}%</Label>
            <Slider
              value={[saturation]}
              onValueChange={([value]) => {
                setSaturation(value)
                updateFromHSL()
              }}
              min={0}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          <div>
            <Label className="text-xs">Lightness: {lightness}%</Label>
            <Slider
              value={[lightness]}
              onValueChange={([value]) => {
                setLightness(value)
                updateFromHSL()
              }}
              min={0}
              max={100}
              step={1}
              className="w-full"
            />
          </div>
        </div>

        {/* Preset Colors */}
        <div>
          <Label className="text-xs mb-2 block">الألوان المحفوظة | Preset Colors</Label>
          <div className="grid grid-cols-5 gap-2">
            {presetColors.map((presetColor) => (
              <button
                key={presetColor}
                className="w-8 h-8 rounded border-2 border-border hover:scale-110 transition-transform"
                style={{ backgroundColor: presetColor }}
                onClick={() => {
                  onChange(presetColor)
                  setHexInput(presetColor)
                }}
              />
            ))}
          </div>
        </div>

        {/* Eyedropper Tool */}
        <Button
          variant="outline"
          size="sm"
          className="w-full gap-2 bg-transparent"
          onClick={() => {
            // TODO: Implement eyedropper functionality
            console.log("Eyedropper tool clicked")
          }}
        >
          <Pipette className="h-4 w-4" />
          أداة القطارة | Eyedropper
        </Button>
      </CardContent>
    </Card>
  )
}
