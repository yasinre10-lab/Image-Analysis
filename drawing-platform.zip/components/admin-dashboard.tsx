"use client"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"
import { AdminOverview } from "@/components/admin-overview"

export function AdminDashboard() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <AdminOverview />
      </AdminLayout>
    </ProtectedRoute>
  )
}
