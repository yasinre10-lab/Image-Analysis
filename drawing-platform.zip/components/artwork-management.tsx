"use client"

import { useState, useEffect } from "react"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"
import { useLanguage } from "@/components/language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download, Trash2, Star, Eye, Filter, ImageIcon, Calendar, MoreHorizontal } from "lucide-react"
import { collection, getDocs, doc, updateDoc, deleteDoc, query, orderBy } from "firebase/firestore"
import { ref, deleteObject, getDownloadURL } from "firebase/storage"
import { db, storage } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Image from "next/image"

interface ArtworkData {
  id: string
  title: string
  description: string
  userId: string
  userName: string
  userEmail: string
  imageUrl: string
  thumbnailUrl?: string
  featured: boolean
  status: "active" | "hidden" | "reported"
  tags: string[]
  createdAt: any
  updatedAt: any
  views: number
  likes: number
}

export function ArtworkManagement() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <ArtworkManagementContent />
      </AdminLayout>
    </ProtectedRoute>
  )
}

function ArtworkManagementContent() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [artworks, setArtworks] = useState<ArtworkData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [featuredFilter, setFeaturedFilter] = useState<string>("all")
  const [selectedArtwork, setSelectedArtwork] = useState<ArtworkData | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  // Load artworks from Firestore
  const loadArtworks = async () => {
    try {
      setLoading(true)
      const artworksRef = collection(db, "artworks")
      const q = query(artworksRef, orderBy("createdAt", "desc"))
      const snapshot = await getDocs(q)

      const artworksData = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        status: doc.data().status || "active",
        featured: doc.data().featured || false,
        views: doc.data().views || 0,
        likes: doc.data().likes || 0,
        tags: doc.data().tags || [],
      })) as ArtworkData[]

      setArtworks(artworksData)
    } catch (error) {
      console.error("Error loading artworks:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل الأعمال الفنية | Failed to load artworks",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadArtworks()
  }, [])

  // Filter artworks based on search and filters
  const filteredArtworks = artworks.filter((artwork) => {
    const matchesSearch =
      artwork.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      artwork.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      artwork.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      artwork.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesStatus = statusFilter === "all" || artwork.status === statusFilter
    const matchesFeatured =
      featuredFilter === "all" ||
      (featuredFilter === "featured" && artwork.featured) ||
      (featuredFilter === "not-featured" && !artwork.featured)

    return matchesSearch && matchesStatus && matchesFeatured
  })

  // Toggle featured status
  const handleToggleFeatured = async (artwork: ArtworkData) => {
    try {
      const artworkRef = doc(db, "artworks", artwork.id)
      const newFeaturedStatus = !artwork.featured

      await updateDoc(artworkRef, {
        featured: newFeaturedStatus,
        updatedAt: new Date(),
      })

      setArtworks(
        artworks.map((a) => (a.id === artwork.id ? { ...a, featured: newFeaturedStatus, updatedAt: new Date() } : a)),
      )

      toast({
        title: newFeaturedStatus ? "تم الإبراز | Featured" : "تم إلغاء الإبراز | Unfeatured",
        description: newFeaturedStatus
          ? "تم إبراز العمل الفني | Artwork has been featured"
          : "تم إلغاء إبراز العمل الفني | Artwork has been unfeatured",
      })
    } catch (error) {
      console.error("Error toggling featured:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تغيير حالة الإبراز | Failed to change featured status",
        variant: "destructive",
      })
    }
  }

  // Update artwork status
  const handleUpdateStatus = async (artwork: ArtworkData, newStatus: "active" | "hidden" | "reported") => {
    try {
      const artworkRef = doc(db, "artworks", artwork.id)

      await updateDoc(artworkRef, {
        status: newStatus,
        updatedAt: new Date(),
      })

      setArtworks(artworks.map((a) => (a.id === artwork.id ? { ...a, status: newStatus, updatedAt: new Date() } : a)))

      toast({
        title: "تم التحديث | Updated",
        description: "تم تحديث حالة العمل الفني | Artwork status updated",
      })
    } catch (error) {
      console.error("Error updating status:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحديث الحالة | Failed to update status",
        variant: "destructive",
      })
    }
  }

  // Delete artwork
  const handleDeleteArtwork = async (artwork: ArtworkData) => {
    try {
      // Delete from Firestore
      await deleteDoc(doc(db, "artworks", artwork.id))

      // Delete from Storage if imageUrl exists
      if (artwork.imageUrl) {
        try {
          const imageRef = ref(storage, artwork.imageUrl)
          await deleteObject(imageRef)
        } catch (storageError) {
          console.warn("Could not delete image from storage:", storageError)
        }
      }

      setArtworks(artworks.filter((a) => a.id !== artwork.id))

      toast({
        title: "تم الحذف | Deleted",
        description: "تم حذف العمل الفني بنجاح | Artwork deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting artwork:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حذف العمل الفني | Failed to delete artwork",
        variant: "destructive",
      })
    }
  }

  // Download artwork
  const handleDownloadArtwork = async (artwork: ArtworkData) => {
    try {
      if (!artwork.imageUrl) {
        toast({
          title: "خطأ | Error",
          description: "رابط الصورة غير متوفر | Image URL not available",
          variant: "destructive",
        })
        return
      }

      const downloadUrl = await getDownloadURL(ref(storage, artwork.imageUrl))
      const link = document.createElement("a")
      link.href = downloadUrl
      link.download = `${artwork.title || "artwork"}.png`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "تم التحميل | Downloaded",
        description: "تم تحميل العمل الفني | Artwork downloaded successfully",
      })
    } catch (error) {
      console.error("Error downloading artwork:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل العمل الفني | Failed to download artwork",
        variant: "destructive",
      })
    }
  }

  const formatDate = (date: any) => {
    if (!date) return "غير محدد | N/A"
    const d = date.toDate ? date.toDate() : new Date(date)
    return d.toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="default">نشط | Active</Badge>
      case "hidden":
        return <Badge variant="secondary">مخفي | Hidden</Badge>
      case "reported":
        return <Badge variant="destructive">مبلغ عنه | Reported</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">إدارة الأعمال الفنية | Artwork Management</h1>
          <p className="text-muted-foreground mt-2">
            إدارة ومراجعة الأعمال الفنية المرفوعة | Manage and moderate uploaded artworks
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="flex items-center gap-2">
            <ImageIcon className="h-4 w-4" />
            {filteredArtworks.length} عمل فني | artworks
          </Badge>
          <Button variant="outline" size="sm" onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}>
            {viewMode === "grid" ? "قائمة | List" : "شبكة | Grid"}
          </Button>
        </div>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            البحث والتصفية | Search & Filter
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>البحث | Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="البحث بالعنوان أو الفنان | Search by title or artist"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>الحالة | Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات | All Status</SelectItem>
                  <SelectItem value="active">نشط | Active</SelectItem>
                  <SelectItem value="hidden">مخفي | Hidden</SelectItem>
                  <SelectItem value="reported">مبلغ عنه | Reported</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>الإبراز | Featured</Label>
              <Select value={featuredFilter} onValueChange={setFeaturedFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل | All</SelectItem>
                  <SelectItem value="featured">مبرز | Featured</SelectItem>
                  <SelectItem value="not-featured">غير مبرز | Not Featured</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="invisible">Actions</Label>
              <Button onClick={loadArtworks} variant="outline" className="w-full bg-transparent">
                تحديث | Refresh
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Artworks Display */}
      <Card>
        <CardHeader>
          <CardTitle>معرض الأعمال الفنية | Artworks Gallery</CardTitle>
          <CardDescription>
            إجمالي {artworks.length} عمل فني، يظهر {filteredArtworks.length} | Total {artworks.length} artworks, showing{" "}
            {filteredArtworks.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
            </div>
          ) : viewMode === "grid" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredArtworks.map((artwork) => (
                <Card key={artwork.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative aspect-square">
                    <Image
                      src={artwork.thumbnailUrl || artwork.imageUrl || "/placeholder.svg?height=200&width=200"}
                      alt={artwork.title}
                      fill
                      className="object-cover"
                    />
                    {artwork.featured && (
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-yellow-500 text-yellow-50">
                          <Star className="h-3 w-3 mr-1" />
                          مبرز | Featured
                        </Badge>
                      </div>
                    )}
                    <div className="absolute top-2 left-2">{getStatusBadge(artwork.status)}</div>
                  </div>

                  <CardContent className="p-4">
                    <h3 className="font-semibold truncate">{artwork.title || "بدون عنوان | Untitled"}</h3>
                    <p className="text-sm text-muted-foreground truncate">بواسطة | By {artwork.userName}</p>
                    <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {artwork.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(artwork.createdAt)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-3">
                      <Button size="sm" variant="outline" onClick={() => setSelectedArtwork(artwork)}>
                        <Eye className="h-3 w-3 mr-1" />
                        عرض | View
                      </Button>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="sm" variant="outline">
                            <MoreHorizontal className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleToggleFeatured(artwork)}>
                            <Star className="h-4 w-4 mr-2" />
                            {artwork.featured ? "إلغاء الإبراز | Unfeature" : "إبراز | Feature"}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownloadArtwork(artwork)}>
                            <Download className="h-4 w-4 mr-2" />
                            تحميل | Download
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(artwork, "hidden")}>
                            إخفاء | Hide
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDeleteArtwork(artwork)} className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            حذف | Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredArtworks.map((artwork) => (
                <Card key={artwork.id} className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="relative w-16 h-16 flex-shrink-0">
                      <Image
                        src={artwork.thumbnailUrl || artwork.imageUrl || "/placeholder.svg?height=64&width=64"}
                        alt={artwork.title}
                        fill
                        className="object-cover rounded"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate">{artwork.title || "بدون عنوان | Untitled"}</h3>
                        {artwork.featured && (
                          <Badge variant="secondary" className="text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            مبرز
                          </Badge>
                        )}
                        {getStatusBadge(artwork.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        بواسطة {artwork.userName} • {formatDate(artwork.createdAt)} • {artwork.views} مشاهدة
                      </p>
                      {artwork.description && (
                        <p className="text-sm text-muted-foreground mt-1 truncate">{artwork.description}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline" onClick={() => setSelectedArtwork(artwork)}>
                        <Eye className="h-3 w-3 mr-1" />
                        عرض
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="sm" variant="outline">
                            <MoreHorizontal className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleToggleFeatured(artwork)}>
                            <Star className="h-4 w-4 mr-2" />
                            {artwork.featured ? "إلغاء الإبراز | Unfeature" : "إبراز | Feature"}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDownloadArtwork(artwork)}>
                            <Download className="h-4 w-4 mr-2" />
                            تحميل | Download
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDeleteArtwork(artwork)} className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            حذف | Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}

          {filteredArtworks.length === 0 && !loading && (
            <div className="text-center py-8">
              <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد أعمال فنية | No artworks found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Artwork Details Dialog */}
      <Dialog open={!!selectedArtwork} onOpenChange={() => setSelectedArtwork(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>تفاصيل العمل الفني | Artwork Details</DialogTitle>
            <DialogDescription>معلومات مفصلة عن العمل الفني | Detailed artwork information</DialogDescription>
          </DialogHeader>

          {selectedArtwork && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="relative aspect-square">
                  <Image
                    src={selectedArtwork.imageUrl || "/placeholder.svg?height=400&width=400"}
                    alt={selectedArtwork.title}
                    fill
                    className="object-cover rounded-lg"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>العنوان | Title</Label>
                  <p className="text-sm mt-1">{selectedArtwork.title || "بدون عنوان | Untitled"}</p>
                </div>

                <div>
                  <Label>الوصف | Description</Label>
                  <p className="text-sm mt-1">{selectedArtwork.description || "لا يوجد وصف | No description"}</p>
                </div>

                <div>
                  <Label>الفنان | Artist</Label>
                  <p className="text-sm mt-1">
                    {selectedArtwork.userName} ({selectedArtwork.userEmail})
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>تاريخ الإنشاء | Created</Label>
                    <p className="text-sm mt-1">{formatDate(selectedArtwork.createdAt)}</p>
                  </div>
                  <div>
                    <Label>آخر تحديث | Updated</Label>
                    <p className="text-sm mt-1">{formatDate(selectedArtwork.updatedAt)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>المشاهدات | Views</Label>
                    <p className="text-sm mt-1">{selectedArtwork.views}</p>
                  </div>
                  <div>
                    <Label>الإعجابات | Likes</Label>
                    <p className="text-sm mt-1">{selectedArtwork.likes}</p>
                  </div>
                </div>

                <div>
                  <Label>الحالة | Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedArtwork.status)}</div>
                </div>

                <div>
                  <Label>الإبراز | Featured</Label>
                  <div className="mt-1">
                    {selectedArtwork.featured ? (
                      <Badge variant="default">مبرز | Featured</Badge>
                    ) : (
                      <Badge variant="secondary">غير مبرز | Not Featured</Badge>
                    )}
                  </div>
                </div>

                {selectedArtwork.tags.length > 0 && (
                  <div>
                    <Label>العلامات | Tags</Label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedArtwork.tags.map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedArtwork(null)}>
              إغلاق | Close
            </Button>
            {selectedArtwork && (
              <div className="flex gap-2">
                <Button onClick={() => handleToggleFeatured(selectedArtwork)}>
                  {selectedArtwork.featured ? "إلغاء الإبراز | Unfeature" : "إبراز | Feature"}
                </Button>
                <Button onClick={() => handleDownloadArtwork(selectedArtwork)}>
                  <Download className="h-4 w-4 mr-2" />
                  تحميل | Download
                </Button>
              </div>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
