"use client"

import { useState, useEffect } from "react"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"
import { useLanguage } from "@/components/language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Brush, Palette, Plus, Edit, Trash2, Circle, Eraser, PaintBucket, Pipette } from "lucide-react"
import { collection, getDocs, doc, updateDoc, deleteDoc, addDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

interface DrawingTool {
  id: string
  name: string
  nameAr: string
  type: "brush" | "shape" | "eraser" | "fill" | "eyedropper"
  icon: string
  enabled: boolean
  defaultSize: number
  minSize: number
  maxSize: number
  defaultOpacity: number
  properties: {
    pressure?: boolean
    smoothing?: boolean
    blending?: string
  }
  order: number
}

interface ColorPalette {
  id: string
  name: string
  nameAr: string
  colors: string[]
  isDefault: boolean
  enabled: boolean
  category: "basic" | "artistic" | "nature" | "custom"
  order: number
}

export function ToolManagement() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <ToolManagementContent />
      </AdminLayout>
    </ProtectedRoute>
  )
}

function ToolManagementContent() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [tools, setTools] = useState<DrawingTool[]>([])
  const [palettes, setPalettes] = useState<ColorPalette[]>([])
  const [loading, setLoading] = useState(true)
  const [editingTool, setEditingTool] = useState<DrawingTool | null>(null)
  const [editingPalette, setEditingPalette] = useState<ColorPalette | null>(null)
  const [toolForm, setToolForm] = useState({
    name: "",
    nameAr: "",
    type: "brush" as DrawingTool["type"],
    enabled: true,
    defaultSize: 10,
    minSize: 1,
    maxSize: 100,
    defaultOpacity: 100,
    properties: {
      pressure: false,
      smoothing: true,
      blending: "normal",
    },
  })
  const [paletteForm, setPaletteForm] = useState({
    name: "",
    nameAr: "",
    colors: ["#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff"],
    isDefault: false,
    enabled: true,
    category: "custom" as ColorPalette["category"],
  })

  const toolIcons = {
    brush: Brush,
    shape: Circle,
    eraser: Eraser,
    fill: PaintBucket,
    eyedropper: Pipette,
  }

  // Load tools and palettes
  const loadData = async () => {
    try {
      setLoading(true)

      // Load tools
      const toolsSnapshot = await getDocs(collection(db, "drawing-tools"))
      const toolsData = toolsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as DrawingTool[]

      // Load palettes
      const palettesSnapshot = await getDocs(collection(db, "color-palettes"))
      const palettesData = palettesSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as ColorPalette[]

      setTools(toolsData.sort((a, b) => a.order - b.order))
      setPalettes(palettesData.sort((a, b) => a.order - b.order))

      // Initialize default tools if none exist
      if (toolsData.length === 0) {
        await initializeDefaultTools()
      }

      // Initialize default palettes if none exist
      if (palettesData.length === 0) {
        await initializeDefaultPalettes()
      }
    } catch (error) {
      console.error("Error loading data:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل البيانات | Failed to load data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Initialize default tools
  const initializeDefaultTools = async () => {
    const defaultTools: Omit<DrawingTool, "id">[] = [
      {
        name: "Brush",
        nameAr: "فرشاة",
        type: "brush",
        icon: "brush",
        enabled: true,
        defaultSize: 10,
        minSize: 1,
        maxSize: 100,
        defaultOpacity: 100,
        properties: { pressure: true, smoothing: true, blending: "normal" },
        order: 1,
      },
      {
        name: "Eraser",
        nameAr: "ممحاة",
        type: "eraser",
        icon: "eraser",
        enabled: true,
        defaultSize: 15,
        minSize: 5,
        maxSize: 50,
        defaultOpacity: 100,
        properties: { pressure: false, smoothing: true, blending: "normal" },
        order: 2,
      },
      {
        name: "Circle",
        nameAr: "دائرة",
        type: "shape",
        icon: "circle",
        enabled: true,
        defaultSize: 20,
        minSize: 5,
        maxSize: 200,
        defaultOpacity: 100,
        properties: { pressure: false, smoothing: false, blending: "normal" },
        order: 3,
      },
      {
        name: "Rectangle",
        nameAr: "مستطيل",
        type: "shape",
        icon: "square",
        enabled: true,
        defaultSize: 20,
        minSize: 5,
        maxSize: 200,
        defaultOpacity: 100,
        properties: { pressure: false, smoothing: false, blending: "normal" },
        order: 4,
      },
    ]

    for (const tool of defaultTools) {
      await addDoc(collection(db, "drawing-tools"), tool)
    }

    await loadData()
  }

  // Initialize default palettes
  const initializeDefaultPalettes = async () => {
    const defaultPalettes: Omit<ColorPalette, "id">[] = [
      {
        name: "Basic Colors",
        nameAr: "الألوان الأساسية",
        colors: ["#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff", "#ffff00", "#ff00ff", "#00ffff"],
        isDefault: true,
        enabled: true,
        category: "basic",
        order: 1,
      },
      {
        name: "Warm Colors",
        nameAr: "الألوان الدافئة",
        colors: ["#ff6b6b", "#ffa726", "#ffcc02", "#ff8a65", "#d32f2f", "#f57c00", "#fbc02d", "#bf360c"],
        isDefault: false,
        enabled: true,
        category: "artistic",
        order: 2,
      },
      {
        name: "Cool Colors",
        nameAr: "الألوان الباردة",
        colors: ["#42a5f5", "#26c6da", "#66bb6a", "#ab47bc", "#1976d2", "#0097a7", "#388e3c", "#7b1fa2"],
        isDefault: false,
        enabled: true,
        category: "artistic",
        order: 3,
      },
      {
        name: "Nature Colors",
        nameAr: "ألوان الطبيعة",
        colors: ["#8bc34a", "#4caf50", "#795548", "#607d8b", "#2e7d32", "#5d4037", "#455a64", "#1b5e20"],
        isDefault: false,
        enabled: true,
        category: "nature",
        order: 4,
      },
    ]

    for (const palette of defaultPalettes) {
      await addDoc(collection(db, "color-palettes"), palette)
    }

    await loadData()
  }

  useEffect(() => {
    loadData()
  }, [])

  // Handle tool operations
  const handleSaveTool = async () => {
    try {
      const toolData = {
        ...toolForm,
        order: editingTool ? editingTool.order : tools.length + 1,
      }

      if (editingTool) {
        await updateDoc(doc(db, "drawing-tools", editingTool.id), toolData)
        setTools(tools.map((t) => (t.id === editingTool.id ? { ...t, ...toolData } : t)))
      } else {
        const docRef = await addDoc(collection(db, "drawing-tools"), toolData)
        setTools([...tools, { id: docRef.id, ...toolData }])
      }

      setEditingTool(null)
      resetToolForm()

      toast({
        title: "تم الحفظ | Saved",
        description: "تم حفظ الأداة بنجاح | Tool saved successfully",
      })
    } catch (error) {
      console.error("Error saving tool:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حفظ الأداة | Failed to save tool",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTool = async (toolId: string) => {
    try {
      await deleteDoc(doc(db, "drawing-tools", toolId))
      setTools(tools.filter((t) => t.id !== toolId))

      toast({
        title: "تم الحذف | Deleted",
        description: "تم حذف الأداة بنجاح | Tool deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting tool:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حذف الأداة | Failed to delete tool",
        variant: "destructive",
      })
    }
  }

  const handleToggleToolEnabled = async (tool: DrawingTool) => {
    try {
      const newEnabled = !tool.enabled
      await updateDoc(doc(db, "drawing-tools", tool.id), { enabled: newEnabled })
      setTools(tools.map((t) => (t.id === tool.id ? { ...t, enabled: newEnabled } : t)))
    } catch (error) {
      console.error("Error toggling tool:", error)
    }
  }

  // Handle palette operations
  const handleSavePalette = async () => {
    try {
      const paletteData = {
        ...paletteForm,
        order: editingPalette ? editingPalette.order : palettes.length + 1,
      }

      if (editingPalette) {
        await updateDoc(doc(db, "color-palettes", editingPalette.id), paletteData)
        setPalettes(palettes.map((p) => (p.id === editingPalette.id ? { ...p, ...paletteData } : p)))
      } else {
        const docRef = await addDoc(collection(db, "color-palettes"), paletteData)
        setPalettes([...palettes, { id: docRef.id, ...paletteData }])
      }

      setEditingPalette(null)
      resetPaletteForm()

      toast({
        title: "تم الحفظ | Saved",
        description: "تم حفظ لوحة الألوان بنجاح | Color palette saved successfully",
      })
    } catch (error) {
      console.error("Error saving palette:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حفظ لوحة الألوان | Failed to save color palette",
        variant: "destructive",
      })
    }
  }

  const handleDeletePalette = async (paletteId: string) => {
    try {
      await deleteDoc(doc(db, "color-palettes", paletteId))
      setPalettes(palettes.filter((p) => p.id !== paletteId))

      toast({
        title: "تم الحذف | Deleted",
        description: "تم حذف لوحة الألوان بنجاح | Color palette deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting palette:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حذف لوحة الألوان | Failed to delete color palette",
        variant: "destructive",
      })
    }
  }

  const handleTogglePaletteEnabled = async (palette: ColorPalette) => {
    try {
      const newEnabled = !palette.enabled
      await updateDoc(doc(db, "color-palettes", palette.id), { enabled: newEnabled })
      setPalettes(palettes.map((p) => (p.id === palette.id ? { ...p, enabled: newEnabled } : p)))
    } catch (error) {
      console.error("Error toggling palette:", error)
    }
  }

  const resetToolForm = () => {
    setToolForm({
      name: "",
      nameAr: "",
      type: "brush",
      enabled: true,
      defaultSize: 10,
      minSize: 1,
      maxSize: 100,
      defaultOpacity: 100,
      properties: {
        pressure: false,
        smoothing: true,
        blending: "normal",
      },
    })
  }

  const resetPaletteForm = () => {
    setPaletteForm({
      name: "",
      nameAr: "",
      colors: ["#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff"],
      isDefault: false,
      enabled: true,
      category: "custom",
    })
  }

  const handleEditTool = (tool: DrawingTool) => {
    setEditingTool(tool)
    setToolForm({
      name: tool.name,
      nameAr: tool.nameAr,
      type: tool.type,
      enabled: tool.enabled,
      defaultSize: tool.defaultSize,
      minSize: tool.minSize,
      maxSize: tool.maxSize,
      defaultOpacity: tool.defaultOpacity,
      properties: tool.properties,
    })
  }

  const handleEditPalette = (palette: ColorPalette) => {
    setEditingPalette(palette)
    setPaletteForm({
      name: palette.name,
      nameAr: palette.nameAr,
      colors: palette.colors,
      isDefault: palette.isDefault,
      enabled: palette.enabled,
      category: palette.category,
    })
  }

  const updatePaletteColor = (index: number, color: string) => {
    const newColors = [...paletteForm.colors]
    newColors[index] = color
    setPaletteForm({ ...paletteForm, colors: newColors })
  }

  const addColorToPalette = () => {
    setPaletteForm({
      ...paletteForm,
      colors: [...paletteForm.colors, "#000000"],
    })
  }

  const removeColorFromPalette = (index: number) => {
    const newColors = paletteForm.colors.filter((_, i) => i !== index)
    setPaletteForm({ ...paletteForm, colors: newColors })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">إدارة الأدوات والألوان | Tool & Color Management</h1>
          <p className="text-muted-foreground mt-2">
            إدارة أدوات الرسم ولوحات الألوان | Manage drawing tools and color palettes
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="flex items-center gap-2">
            <Brush className="h-4 w-4" />
            {tools.length} أداة | tools
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            {palettes.length} لوحة | palettes
          </Badge>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="tools" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="tools">أدوات الرسم | Drawing Tools</TabsTrigger>
          <TabsTrigger value="palettes">لوحات الألوان | Color Palettes</TabsTrigger>
        </TabsList>

        {/* Tools Tab */}
        <TabsContent value="tools" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>أدوات الرسم | Drawing Tools</CardTitle>
                <CardDescription>إدارة الأدوات المتاحة للمستخدمين | Manage available tools for users</CardDescription>
              </div>
              <Button
                onClick={() => {
                  resetToolForm()
                  setEditingTool(null)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                إضافة أداة | Add Tool
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {tools.map((tool) => {
                    const IconComponent = toolIcons[tool.type] || Brush
                    return (
                      <Card key={tool.id} className={`p-4 ${!tool.enabled ? "opacity-50" : ""}`}>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              <IconComponent className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold">
                                {tool.nameAr} | {tool.name}
                              </h3>
                              <p className="text-sm text-muted-foreground capitalize">{tool.type}</p>
                            </div>
                          </div>
                          <Switch checked={tool.enabled} onCheckedChange={() => handleToggleToolEnabled(tool)} />
                        </div>

                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>الحجم الافتراضي | Default Size:</span>
                            <span>{tool.defaultSize}px</span>
                          </div>
                          <div className="flex justify-between">
                            <span>النطاق | Range:</span>
                            <span>
                              {tool.minSize}-{tool.maxSize}px
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>الشفافية | Opacity:</span>
                            <span>{tool.defaultOpacity}%</span>
                          </div>
                        </div>

                        <div className="flex gap-2 mt-4">
                          <Button size="sm" variant="outline" onClick={() => handleEditTool(tool)}>
                            <Edit className="h-3 w-3 mr-1" />
                            تعديل | Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteTool(tool.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            حذف | Delete
                          </Button>
                        </div>
                      </Card>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Palettes Tab */}
        <TabsContent value="palettes" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>لوحات الألوان | Color Palettes</CardTitle>
                <CardDescription>إدارة لوحات الألوان المتاحة | Manage available color palettes</CardDescription>
              </div>
              <Button
                onClick={() => {
                  resetPaletteForm()
                  setEditingPalette(null)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                إضافة لوحة | Add Palette
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {palettes.map((palette) => (
                    <Card key={palette.id} className={`p-4 ${!palette.enabled ? "opacity-50" : ""}`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div>
                            <h3 className="font-semibold flex items-center gap-2">
                              {palette.nameAr} | {palette.name}
                              {palette.isDefault && (
                                <Badge variant="secondary" className="text-xs">
                                  افتراضي | Default
                                </Badge>
                              )}
                            </h3>
                            <p className="text-sm text-muted-foreground capitalize">{palette.category}</p>
                          </div>
                        </div>
                        <Switch checked={palette.enabled} onCheckedChange={() => handleTogglePaletteEnabled(palette)} />
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {palette.colors.map((color, index) => (
                          <div
                            key={index}
                            className="w-8 h-8 rounded border-2 border-border"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleEditPalette(palette)}>
                          <Edit className="h-3 w-3 mr-1" />
                          تعديل | Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeletePalette(palette.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          حذف | Delete
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Tool Edit Dialog */}
      <Dialog
        open={editingTool !== null || (editingTool === null && toolForm.name !== "")}
        onOpenChange={(open) => {
          if (!open) {
            setEditingTool(null)
            resetToolForm()
          }
        }}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingTool ? "تعديل الأداة | Edit Tool" : "إضافة أداة جديدة | Add New Tool"}</DialogTitle>
            <DialogDescription>
              تكوين خصائص الأداة والإعدادات | Configure tool properties and settings
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>الاسم بالإنجليزية | English Name</Label>
                <Input
                  value={toolForm.name}
                  onChange={(e) => setToolForm({ ...toolForm, name: e.target.value })}
                  placeholder="Tool name"
                />
              </div>

              <div className="space-y-2">
                <Label>الاسم بالعربية | Arabic Name</Label>
                <Input
                  value={toolForm.nameAr}
                  onChange={(e) => setToolForm({ ...toolForm, nameAr: e.target.value })}
                  placeholder="اسم الأداة"
                />
              </div>

              <div className="space-y-2">
                <Label>نوع الأداة | Tool Type</Label>
                <Select
                  value={toolForm.type}
                  onValueChange={(value: DrawingTool["type"]) => setToolForm({ ...toolForm, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="brush">فرشاة | Brush</SelectItem>
                    <SelectItem value="shape">شكل | Shape</SelectItem>
                    <SelectItem value="eraser">ممحاة | Eraser</SelectItem>
                    <SelectItem value="fill">تعبئة | Fill</SelectItem>
                    <SelectItem value="eyedropper">قطارة | Eyedropper</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={toolForm.enabled}
                  onCheckedChange={(enabled) => setToolForm({ ...toolForm, enabled })}
                />
                <Label>مفعل | Enabled</Label>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>الحجم الافتراضي | Default Size: {toolForm.defaultSize}px</Label>
                <Slider
                  value={[toolForm.defaultSize]}
                  onValueChange={([value]) => setToolForm({ ...toolForm, defaultSize: value })}
                  min={1}
                  max={100}
                  step={1}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الحد الأدنى | Min Size</Label>
                  <Input
                    type="number"
                    value={toolForm.minSize}
                    onChange={(e) => setToolForm({ ...toolForm, minSize: Number.parseInt(e.target.value) || 1 })}
                    min={1}
                    max={toolForm.maxSize}
                  />
                </div>
                <div className="space-y-2">
                  <Label>الحد الأقصى | Max Size</Label>
                  <Input
                    type="number"
                    value={toolForm.maxSize}
                    onChange={(e) => setToolForm({ ...toolForm, maxSize: Number.parseInt(e.target.value) || 100 })}
                    min={toolForm.minSize}
                    max={200}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>الشفافية الافتراضية | Default Opacity: {toolForm.defaultOpacity}%</Label>
                <Slider
                  value={[toolForm.defaultOpacity]}
                  onValueChange={([value]) => setToolForm({ ...toolForm, defaultOpacity: value })}
                  min={1}
                  max={100}
                  step={1}
                />
              </div>

              <div className="space-y-3">
                <Label>خصائص إضافية | Additional Properties</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={toolForm.properties.pressure}
                      onCheckedChange={(pressure) =>
                        setToolForm({
                          ...toolForm,
                          properties: { ...toolForm.properties, pressure },
                        })
                      }
                    />
                    <Label>حساسية الضغط | Pressure Sensitivity</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={toolForm.properties.smoothing}
                      onCheckedChange={(smoothing) =>
                        setToolForm({
                          ...toolForm,
                          properties: { ...toolForm.properties, smoothing },
                        })
                      }
                    />
                    <Label>تنعيم الخطوط | Line Smoothing</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setEditingTool(null)
                resetToolForm()
              }}
            >
              إلغاء | Cancel
            </Button>
            <Button onClick={handleSaveTool}>
              {editingTool ? "حفظ التغييرات | Save Changes" : "إضافة الأداة | Add Tool"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Palette Edit Dialog */}
      <Dialog
        open={editingPalette !== null || (editingPalette === null && paletteForm.name !== "")}
        onOpenChange={(open) => {
          if (!open) {
            setEditingPalette(null)
            resetPaletteForm()
          }
        }}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingPalette ? "تعديل لوحة الألوان | Edit Palette" : "إضافة لوحة ألوان جديدة | Add New Palette"}
            </DialogTitle>
            <DialogDescription>تكوين لوحة الألوان والإعدادات | Configure color palette and settings</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>الاسم بالإنجليزية | English Name</Label>
                <Input
                  value={paletteForm.name}
                  onChange={(e) => setPaletteForm({ ...paletteForm, name: e.target.value })}
                  placeholder="Palette name"
                />
              </div>

              <div className="space-y-2">
                <Label>الاسم بالعربية | Arabic Name</Label>
                <Input
                  value={paletteForm.nameAr}
                  onChange={(e) => setPaletteForm({ ...paletteForm, nameAr: e.target.value })}
                  placeholder="اسم لوحة الألوان"
                />
              </div>

              <div className="space-y-2">
                <Label>الفئة | Category</Label>
                <Select
                  value={paletteForm.category}
                  onValueChange={(value: ColorPalette["category"]) =>
                    setPaletteForm({ ...paletteForm, category: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="basic">أساسي | Basic</SelectItem>
                    <SelectItem value="artistic">فني | Artistic</SelectItem>
                    <SelectItem value="nature">طبيعة | Nature</SelectItem>
                    <SelectItem value="custom">مخصص | Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={paletteForm.enabled}
                    onCheckedChange={(enabled) => setPaletteForm({ ...paletteForm, enabled })}
                  />
                  <Label>مفعل | Enabled</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={paletteForm.isDefault}
                    onCheckedChange={(isDefault) => setPaletteForm({ ...paletteForm, isDefault })}
                  />
                  <Label>افتراضي | Default</Label>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>الألوان | Colors ({paletteForm.colors.length})</Label>
                <Button size="sm" onClick={addColorToPalette}>
                  <Plus className="h-3 w-3 mr-1" />
                  إضافة لون | Add Color
                </Button>
              </div>

              <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
                {paletteForm.colors.map((color, index) => (
                  <div key={index} className="space-y-2">
                    <div className="relative">
                      <input
                        type="color"
                        value={color}
                        onChange={(e) => updatePaletteColor(index, e.target.value)}
                        className="w-full h-12 rounded border-2 border-border cursor-pointer"
                      />
                      {paletteForm.colors.length > 1 && (
                        <Button
                          size="sm"
                          variant="destructive"
                          className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full"
                          onClick={() => removeColorFromPalette(index)}
                        >
                          ×
                        </Button>
                      )}
                    </div>
                    <Input
                      value={color}
                      onChange={(e) => updatePaletteColor(index, e.target.value)}
                      className="text-xs text-center"
                      placeholder="#000000"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setEditingPalette(null)
                resetPaletteForm()
              }}
            >
              إلغاء | Cancel
            </Button>
            <Button onClick={handleSavePalette}>
              {editingPalette ? "حفظ التغييرات | Save Changes" : "إضافة اللوحة | Add Palette"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
