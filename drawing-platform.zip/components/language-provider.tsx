"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"

type Language = "ar" | "en"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

// Translation dictionary
const translations = {
  ar: {
    // Homepage
    "homepage.title": "منصة الرسم الاحترافية",
    "homepage.subtitle": "أطلق إبداعك مع أدوات الرسم المتقدمة",
    "homepage.startDrawing": "ابدأ الرسم",
    "homepage.login": "تسجيل الدخول",
    "homepage.register": "إنشاء حساب",
    "homepage.features": "المميزات",
    "homepage.gallery": "معرض الأعمال",

    // Auth
    "auth.email": "البريد الإلكتروني",
    "auth.password": "كلمة المرور",
    "auth.login": "تسجيل الدخول",
    "auth.register": "إنشاء حساب جديد",
    "auth.backToHome": "العودة للصفحة الرئيسية",

    // Drawing
    "drawing.brush": "الفرشاة",
    "drawing.eraser": "الممحاة",
    "drawing.color": "اللون",
    "drawing.layers": "الطبقات",
    "drawing.undo": "تراجع",
    "drawing.redo": "إعادة",
    "drawing.save": "حفظ",
    "drawing.load": "تحميل",
    "drawing.zoom": "تكبير/تصغير",

    // Dashboard
    "dashboard.title": "لوحة التحكم",
    "dashboard.users": "المستخدمون",
    "dashboard.artworks": "الأعمال الفنية",
    "dashboard.statistics": "الإحصائيات",

    // Common
    "common.darkMode": "الوضع الليلي",
    "common.lightMode": "الوضع الفاتح",
    "common.language": "اللغة",
  },
  en: {
    // Homepage
    "homepage.title": "Professional Drawing Platform",
    "homepage.subtitle": "Unleash your creativity with advanced drawing tools",
    "homepage.startDrawing": "Start Drawing",
    "homepage.login": "Login",
    "homepage.register": "Sign Up",
    "homepage.features": "Features",
    "homepage.gallery": "Gallery",

    // Auth
    "auth.email": "Email",
    "auth.password": "Password",
    "auth.login": "Login",
    "auth.register": "Create New Account",
    "auth.backToHome": "Back to Home",

    // Drawing
    "drawing.brush": "Brush",
    "drawing.eraser": "Eraser",
    "drawing.color": "Color",
    "drawing.layers": "Layers",
    "drawing.undo": "Undo",
    "drawing.redo": "Redo",
    "drawing.save": "Save",
    "drawing.load": "Load",
    "drawing.zoom": "Zoom",

    // Dashboard
    "dashboard.title": "Dashboard",
    "dashboard.users": "Users",
    "dashboard.artworks": "Artworks",
    "dashboard.statistics": "Statistics",

    // Common
    "common.darkMode": "Dark Mode",
    "common.lightMode": "Light Mode",
    "common.language": "Language",
  },
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar")

  useEffect(() => {
    // Load language from localStorage
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "ar" || savedLanguage === "en")) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    // Update document attributes when language changes
    document.documentElement.lang = language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
    localStorage.setItem("language", language)
  }, [language])

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)[typeof language]] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
