"use client"

import { useState, useEffect } from "react"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"
import { useLanguage } from "@/components/language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Globe, Shield, Palette, Users, Mail, Database, AlertTriangle, Save, RefreshCw } from "lucide-react"
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

interface SiteSettingsData {
  // General Settings
  siteName: string
  siteNameAr: string
  siteDescription: string
  siteDescriptionAr: string
  siteUrl: string
  contactEmail: string

  // Feature Toggles
  enableRegistration: boolean
  enablePublicGallery: boolean
  enableComments: boolean
  enableLikes: boolean
  enableSharing: boolean
  enableDownloads: boolean

  // Appearance
  defaultTheme: "light" | "dark" | "system"
  defaultLanguage: "en" | "ar" | "auto"
  enableThemeToggle: boolean
  enableLanguageToggle: boolean

  // Limits & Restrictions
  maxFileSize: number // MB
  maxCanvasSize: number // pixels
  maxLayersPerDrawing: number
  maxDrawingsPerUser: number
  allowedFileTypes: string[]

  // Content Moderation
  enableAutoModeration: boolean
  requireApproval: boolean
  bannedWords: string[]

  // Privacy & Security
  enableAnalytics: boolean
  cookieConsent: boolean
  dataRetentionDays: number
  enableTwoFactor: boolean

  // Maintenance
  maintenanceMode: boolean
  maintenanceMessage: string
  maintenanceMessageAr: string

  // Email Settings
  enableEmailNotifications: boolean
  welcomeEmailEnabled: boolean
  moderationEmailEnabled: boolean

  // Performance
  enableCaching: boolean
  cacheTimeout: number // minutes
  enableCompression: boolean

  // Social Features
  enableUserProfiles: boolean
  enableFollowing: boolean
  enableMessaging: boolean

  updatedAt: Date
  updatedBy: string
}

export function SiteSettings() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <SiteSettingsContent />
      </AdminLayout>
    </ProtectedRoute>
  )
}

function SiteSettingsContent() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [settings, setSettings] = useState<SiteSettingsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Default settings
  const defaultSettings: SiteSettingsData = {
    siteName: "Drawing Platform",
    siteNameAr: "منصة الرسم",
    siteDescription: "A creative platform for digital art and drawing",
    siteDescriptionAr: "منصة إبداعية للفن الرقمي والرسم",
    siteUrl: "https://drawing-platform.com",
    contactEmail: "admin@drawing-platform.com",

    enableRegistration: true,
    enablePublicGallery: true,
    enableComments: true,
    enableLikes: true,
    enableSharing: true,
    enableDownloads: true,

    defaultTheme: "system",
    defaultLanguage: "auto",
    enableThemeToggle: true,
    enableLanguageToggle: true,

    maxFileSize: 10,
    maxCanvasSize: 4000,
    maxLayersPerDrawing: 20,
    maxDrawingsPerUser: 100,
    allowedFileTypes: ["png", "jpg", "jpeg", "gif"],

    enableAutoModeration: false,
    requireApproval: false,
    bannedWords: [],

    enableAnalytics: true,
    cookieConsent: true,
    dataRetentionDays: 365,
    enableTwoFactor: false,

    maintenanceMode: false,
    maintenanceMessage: "Site is under maintenance. Please check back later.",
    maintenanceMessageAr: "الموقع تحت الصيانة. يرجى المحاولة لاحقاً.",

    enableEmailNotifications: true,
    welcomeEmailEnabled: true,
    moderationEmailEnabled: true,

    enableCaching: true,
    cacheTimeout: 60,
    enableCompression: true,

    enableUserProfiles: true,
    enableFollowing: false,
    enableMessaging: false,

    updatedAt: new Date(),
    updatedBy: "admin",
  }

  // Load settings
  const loadSettings = async () => {
    try {
      setLoading(true)
      const settingsDoc = await getDoc(doc(db, "site-settings", "global"))

      if (settingsDoc.exists()) {
        setSettings({ ...defaultSettings, ...settingsDoc.data() } as SiteSettingsData)
      } else {
        // Initialize with default settings
        await setDoc(doc(db, "site-settings", "global"), defaultSettings)
        setSettings(defaultSettings)
      }
    } catch (error) {
      console.error("Error loading settings:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل الإعدادات | Failed to load settings",
        variant: "destructive",
      })
      setSettings(defaultSettings)
    } finally {
      setLoading(false)
    }
  }

  // Save settings
  const saveSettings = async () => {
    if (!settings) return

    try {
      setSaving(true)
      const updatedSettings = {
        ...settings,
        updatedAt: new Date(),
        updatedBy: "admin", // In real app, get from auth context
      }

      await updateDoc(doc(db, "site-settings", "global"), updatedSettings)
      setSettings(updatedSettings)

      toast({
        title: "تم الحفظ | Saved",
        description: "تم حفظ الإعدادات بنجاح | Settings saved successfully",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حفظ الإعدادات | Failed to save settings",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  // Reset to defaults
  const resetToDefaults = async () => {
    try {
      await setDoc(doc(db, "site-settings", "global"), defaultSettings)
      setSettings(defaultSettings)

      toast({
        title: "تم الإعادة | Reset",
        description: "تم إعادة تعيين الإعدادات للقيم الافتراضية | Settings reset to defaults",
      })
    } catch (error) {
      console.error("Error resetting settings:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في إعادة تعيين الإعدادات | Failed to reset settings",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    loadSettings()
  }, [])

  const updateSetting = (key: keyof SiteSettingsData, value: any) => {
    if (!settings) return
    setSettings({ ...settings, [key]: value })
  }

  const addBannedWord = (word: string) => {
    if (!settings || !word.trim()) return
    const newWords = [...settings.bannedWords, word.trim()]
    updateSetting("bannedWords", newWords)
  }

  const removeBannedWord = (index: number) => {
    if (!settings) return
    const newWords = settings.bannedWords.filter((_, i) => i !== index)
    updateSetting("bannedWords", newWords)
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
      </div>
    )
  }

  if (!settings) return null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">إعدادات الموقع | Site Settings</h1>
          <p className="text-muted-foreground mt-2">تكوين الإعدادات العامة للموقع | Configure global site settings</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={resetToDefaults}>
            <RefreshCw className="h-4 w-4 mr-2" />
            إعادة تعيين | Reset
          </Button>
          <Button onClick={saveSettings} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? "جاري الحفظ | Saving..." : "حفظ | Save"}
          </Button>
        </div>
      </div>

      {/* Maintenance Mode Alert */}
      {settings.maintenanceMode && (
        <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-orange-800 dark:text-orange-200">
              <AlertTriangle className="h-5 w-5" />
              <span className="font-semibold">وضع الصيانة مفعل | Maintenance Mode Active</span>
            </div>
            <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
              الموقع في وضع الصيانة حالياً | The site is currently in maintenance mode
            </p>
          </CardContent>
        </Card>
      )}

      {/* Settings Tabs */}
      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
          <TabsTrigger value="general">عام | General</TabsTrigger>
          <TabsTrigger value="features">الميزات | Features</TabsTrigger>
          <TabsTrigger value="security">الأمان | Security</TabsTrigger>
          <TabsTrigger value="advanced">متقدم | Advanced</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  معلومات الموقع | Site Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>اسم الموقع (إنجليزي) | Site Name (English)</Label>
                  <Input
                    value={settings.siteName}
                    onChange={(e) => updateSetting("siteName", e.target.value)}
                    placeholder="Drawing Platform"
                  />
                </div>

                <div className="space-y-2">
                  <Label>اسم الموقع (عربي) | Site Name (Arabic)</Label>
                  <Input
                    value={settings.siteNameAr}
                    onChange={(e) => updateSetting("siteNameAr", e.target.value)}
                    placeholder="منصة الرسم"
                  />
                </div>

                <div className="space-y-2">
                  <Label>وصف الموقع (إنجليزي) | Site Description (English)</Label>
                  <Textarea
                    value={settings.siteDescription}
                    onChange={(e) => updateSetting("siteDescription", e.target.value)}
                    placeholder="A creative platform for digital art"
                  />
                </div>

                <div className="space-y-2">
                  <Label>وصف الموقع (عربي) | Site Description (Arabic)</Label>
                  <Textarea
                    value={settings.siteDescriptionAr}
                    onChange={(e) => updateSetting("siteDescriptionAr", e.target.value)}
                    placeholder="منصة إبداعية للفن الرقمي"
                  />
                </div>

                <div className="space-y-2">
                  <Label>رابط الموقع | Site URL</Label>
                  <Input
                    value={settings.siteUrl}
                    onChange={(e) => updateSetting("siteUrl", e.target.value)}
                    placeholder="https://drawing-platform.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label>بريد التواصل | Contact Email</Label>
                  <Input
                    type="email"
                    value={settings.contactEmail}
                    onChange={(e) => updateSetting("contactEmail", e.target.value)}
                    placeholder="admin@drawing-platform.com"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  المظهر واللغة | Appearance & Language
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>المظهر الافتراضي | Default Theme</Label>
                  <Select
                    value={settings.defaultTheme}
                    onValueChange={(value: "light" | "dark" | "system") => updateSetting("defaultTheme", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">فاتح | Light</SelectItem>
                      <SelectItem value="dark">داكن | Dark</SelectItem>
                      <SelectItem value="system">النظام | System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>اللغة الافتراضية | Default Language</Label>
                  <Select
                    value={settings.defaultLanguage}
                    onValueChange={(value: "en" | "ar" | "auto") => updateSetting("defaultLanguage", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="auto">تلقائي | Auto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>تبديل المظهر | Theme Toggle</Label>
                    <Switch
                      checked={settings.enableThemeToggle}
                      onCheckedChange={(checked) => updateSetting("enableThemeToggle", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>تبديل اللغة | Language Toggle</Label>
                    <Switch
                      checked={settings.enableLanguageToggle}
                      onCheckedChange={(checked) => updateSetting("enableLanguageToggle", checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                الحدود والقيود | Limits & Restrictions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>حجم الملف الأقصى | Max File Size: {settings.maxFileSize}MB</Label>
                  <Slider
                    value={[settings.maxFileSize]}
                    onValueChange={([value]) => updateSetting("maxFileSize", value)}
                    min={1}
                    max={50}
                    step={1}
                  />
                </div>

                <div className="space-y-2">
                  <Label>حجم اللوحة الأقصى | Max Canvas Size: {settings.maxCanvasSize}px</Label>
                  <Slider
                    value={[settings.maxCanvasSize]}
                    onValueChange={([value]) => updateSetting("maxCanvasSize", value)}
                    min={1000}
                    max={8000}
                    step={100}
                  />
                </div>

                <div className="space-y-2">
                  <Label>الطبقات الأقصى | Max Layers: {settings.maxLayersPerDrawing}</Label>
                  <Slider
                    value={[settings.maxLayersPerDrawing]}
                    onValueChange={([value]) => updateSetting("maxLayersPerDrawing", value)}
                    min={1}
                    max={50}
                    step={1}
                  />
                </div>

                <div className="space-y-2">
                  <Label>الرسوم لكل مستخدم | Drawings per User: {settings.maxDrawingsPerUser}</Label>
                  <Slider
                    value={[settings.maxDrawingsPerUser]}
                    onValueChange={([value]) => updateSetting("maxDrawingsPerUser", value)}
                    min={10}
                    max={1000}
                    step={10}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Features Settings */}
        <TabsContent value="features" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  ميزات المستخدمين | User Features
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>تسجيل المستخدمين | User Registration</Label>
                  <Switch
                    checked={settings.enableRegistration}
                    onCheckedChange={(checked) => updateSetting("enableRegistration", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>الملفات الشخصية | User Profiles</Label>
                  <Switch
                    checked={settings.enableUserProfiles}
                    onCheckedChange={(checked) => updateSetting("enableUserProfiles", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>المتابعة | Following</Label>
                  <Switch
                    checked={settings.enableFollowing}
                    onCheckedChange={(checked) => updateSetting("enableFollowing", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>الرسائل | Messaging</Label>
                  <Switch
                    checked={settings.enableMessaging}
                    onCheckedChange={(checked) => updateSetting("enableMessaging", checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>ميزات المحتوى | Content Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>المعرض العام | Public Gallery</Label>
                  <Switch
                    checked={settings.enablePublicGallery}
                    onCheckedChange={(checked) => updateSetting("enablePublicGallery", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>التعليقات | Comments</Label>
                  <Switch
                    checked={settings.enableComments}
                    onCheckedChange={(checked) => updateSetting("enableComments", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>الإعجابات | Likes</Label>
                  <Switch
                    checked={settings.enableLikes}
                    onCheckedChange={(checked) => updateSetting("enableLikes", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>المشاركة | Sharing</Label>
                  <Switch
                    checked={settings.enableSharing}
                    onCheckedChange={(checked) => updateSetting("enableSharing", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>التحميل | Downloads</Label>
                  <Switch
                    checked={settings.enableDownloads}
                    onCheckedChange={(checked) => updateSetting("enableDownloads", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                إعدادات البريد الإلكتروني | Email Settings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center justify-between">
                  <Label>إشعارات البريد | Email Notifications</Label>
                  <Switch
                    checked={settings.enableEmailNotifications}
                    onCheckedChange={(checked) => updateSetting("enableEmailNotifications", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>بريد الترحيب | Welcome Email</Label>
                  <Switch
                    checked={settings.welcomeEmailEnabled}
                    onCheckedChange={(checked) => updateSetting("welcomeEmailEnabled", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>بريد الإشراف | Moderation Email</Label>
                  <Switch
                    checked={settings.moderationEmailEnabled}
                    onCheckedChange={(checked) => updateSetting("moderationEmailEnabled", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  الأمان والخصوصية | Security & Privacy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>التحليلات | Analytics</Label>
                  <Switch
                    checked={settings.enableAnalytics}
                    onCheckedChange={(checked) => updateSetting("enableAnalytics", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>موافقة الكوكيز | Cookie Consent</Label>
                  <Switch
                    checked={settings.cookieConsent}
                    onCheckedChange={(checked) => updateSetting("cookieConsent", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>المصادقة الثنائية | Two-Factor Auth</Label>
                  <Switch
                    checked={settings.enableTwoFactor}
                    onCheckedChange={(checked) => updateSetting("enableTwoFactor", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>مدة الاحتفاظ بالبيانات | Data Retention: {settings.dataRetentionDays} يوم | days</Label>
                  <Slider
                    value={[settings.dataRetentionDays]}
                    onValueChange={([value]) => updateSetting("dataRetentionDays", value)}
                    min={30}
                    max={1095}
                    step={30}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>إشراف المحتوى | Content Moderation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>الإشراف التلقائي | Auto Moderation</Label>
                  <Switch
                    checked={settings.enableAutoModeration}
                    onCheckedChange={(checked) => updateSetting("enableAutoModeration", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>يتطلب موافقة | Require Approval</Label>
                  <Switch
                    checked={settings.requireApproval}
                    onCheckedChange={(checked) => updateSetting("requireApproval", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>الكلمات المحظورة | Banned Words</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="أضف كلمة محظورة | Add banned word"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          addBannedWord(e.currentTarget.value)
                          e.currentTarget.value = ""
                        }
                      }}
                    />
                    <Button
                      size="sm"
                      onClick={() => {
                        const input = document.querySelector('input[placeholder*="banned"]') as HTMLInputElement
                        if (input?.value) {
                          addBannedWord(input.value)
                          input.value = ""
                        }
                      }}
                    >
                      إضافة | Add
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {settings.bannedWords.map((word, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="cursor-pointer"
                        onClick={() => removeBannedWord(index)}
                      >
                        {word} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Advanced Settings */}
        <TabsContent value="advanced" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  وضع الصيانة | Maintenance Mode
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>تفعيل وضع الصيانة | Enable Maintenance Mode</Label>
                  <Switch
                    checked={settings.maintenanceMode}
                    onCheckedChange={(checked) => updateSetting("maintenanceMode", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>رسالة الصيانة (إنجليزي) | Maintenance Message (English)</Label>
                  <Textarea
                    value={settings.maintenanceMessage}
                    onChange={(e) => updateSetting("maintenanceMessage", e.target.value)}
                    placeholder="Site is under maintenance..."
                  />
                </div>

                <div className="space-y-2">
                  <Label>رسالة الصيانة (عربي) | Maintenance Message (Arabic)</Label>
                  <Textarea
                    value={settings.maintenanceMessageAr}
                    onChange={(e) => updateSetting("maintenanceMessageAr", e.target.value)}
                    placeholder="الموقع تحت الصيانة..."
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>الأداء | Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>التخزين المؤقت | Caching</Label>
                  <Switch
                    checked={settings.enableCaching}
                    onCheckedChange={(checked) => updateSetting("enableCaching", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>مهلة التخزين المؤقت | Cache Timeout: {settings.cacheTimeout} دقيقة | minutes</Label>
                  <Slider
                    value={[settings.cacheTimeout]}
                    onValueChange={([value]) => updateSetting("cacheTimeout", value)}
                    min={5}
                    max={1440}
                    step={5}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>ضغط البيانات | Data Compression</Label>
                  <Switch
                    checked={settings.enableCompression}
                    onCheckedChange={(checked) => updateSetting("enableCompression", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>معلومات النظام | System Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <Label>آخر تحديث | Last Updated</Label>
                  <p className="text-muted-foreground">
                    {settings.updatedAt ? new Date(settings.updatedAt).toLocaleString("ar-EG") : "غير محدد | N/A"}
                  </p>
                </div>
                <div>
                  <Label>تم التحديث بواسطة | Updated By</Label>
                  <p className="text-muted-foreground">{settings.updatedBy}</p>
                </div>
                <div>
                  <Label>إصدار الإعدادات | Settings Version</Label>
                  <p className="text-muted-foreground">1.0.0</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
