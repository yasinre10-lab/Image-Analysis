"use client"

import { useState, useEffect } from "react"
import { ProtectedRoute } from "@/components/protected-route"
import { AdminLayout } from "@/components/admin-layout"
import { useLanguage } from "@/components/language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Edit, Trash2, Ban, UserCheck, Users, Filter, MoreHorizontal } from "lucide-react"
import { collection, getDocs, doc, updateDoc, deleteDoc, query, orderBy } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface UserData {
  uid: string
  email: string
  displayName: string
  role: "user" | "admin"
  status: "active" | "banned"
  createdAt: any
  lastLoginAt: any
}

export function UserManagement() {
  return (
    <ProtectedRoute requireAdmin={true} redirectTo="/">
      <AdminLayout>
        <UserManagementContent />
      </AdminLayout>
    </ProtectedRoute>
  )
}

function UserManagementContent() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [users, setUsers] = useState<UserData[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [editingUser, setEditingUser] = useState<UserData | null>(null)
  const [editForm, setEditForm] = useState({
    displayName: "",
    email: "",
    role: "user" as "user" | "admin",
    status: "active" as "active" | "banned",
  })

  // Load users from Firestore
  const loadUsers = async () => {
    try {
      setLoading(true)
      const usersRef = collection(db, "users")
      const q = query(usersRef, orderBy("createdAt", "desc"))
      const snapshot = await getDocs(q)

      const usersData = snapshot.docs.map((doc) => ({
        uid: doc.id,
        ...doc.data(),
        status: doc.data().status || "active",
      })) as UserData[]

      setUsers(usersData)
    } catch (error) {
      console.error("Error loading users:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل المستخدمين | Failed to load users",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  // Filter users based on search and filters
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = roleFilter === "all" || user.role === roleFilter
    const matchesStatus = statusFilter === "all" || user.status === statusFilter

    return matchesSearch && matchesRole && matchesStatus
  })

  // Handle user edit
  const handleEditUser = (user: UserData) => {
    setEditingUser(user)
    setEditForm({
      displayName: user.displayName,
      email: user.email,
      role: user.role,
      status: user.status,
    })
  }

  // Save user changes
  const handleSaveUser = async () => {
    if (!editingUser) return

    try {
      const userRef = doc(db, "users", editingUser.uid)
      await updateDoc(userRef, {
        displayName: editForm.displayName,
        role: editForm.role,
        status: editForm.status,
        updatedAt: new Date(),
      })

      // Update local state
      setUsers(
        users.map((user) => (user.uid === editingUser.uid ? { ...user, ...editForm, updatedAt: new Date() } : user)),
      )

      setEditingUser(null)
      toast({
        title: "تم التحديث | Updated",
        description: "تم تحديث بيانات المستخدم بنجاح | User data updated successfully",
      })
    } catch (error) {
      console.error("Error updating user:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحديث المستخدم | Failed to update user",
        variant: "destructive",
      })
    }
  }

  // Delete user
  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteDoc(doc(db, "users", userId))
      setUsers(users.filter((user) => user.uid !== userId))

      toast({
        title: "تم الحذف | Deleted",
        description: "تم حذف المستخدم بنجاح | User deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting user:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في حذف المستخدم | Failed to delete user",
        variant: "destructive",
      })
    }
  }

  // Toggle user ban status
  const handleToggleBan = async (user: UserData) => {
    try {
      const newStatus = user.status === "banned" ? "active" : "banned"
      const userRef = doc(db, "users", user.uid)

      await updateDoc(userRef, {
        status: newStatus,
        updatedAt: new Date(),
      })

      setUsers(users.map((u) => (u.uid === user.uid ? { ...u, status: newStatus, updatedAt: new Date() } : u)))

      toast({
        title: newStatus === "banned" ? "تم الحظر | Banned" : "تم إلغاء الحظر | Unbanned",
        description:
          newStatus === "banned"
            ? "تم حظر المستخدم | User has been banned"
            : "تم إلغاء حظر المستخدم | User has been unbanned",
      })
    } catch (error) {
      console.error("Error toggling ban:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تغيير حالة المستخدم | Failed to change user status",
        variant: "destructive",
      })
    }
  }

  const formatDate = (date: any) => {
    if (!date) return "غير محدد | N/A"
    const d = date.toDate ? date.toDate() : new Date(date)
    return d.toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">إدارة المستخدمين | User Management</h1>
          <p className="text-muted-foreground mt-2">
            إدارة وتحكم في حسابات المستخدمين | Manage and control user accounts
          </p>
        </div>
        <Badge variant="secondary" className="flex items-center gap-2">
          <Users className="h-4 w-4" />
          {filteredUsers.length} مستخدم | users
        </Badge>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            البحث والتصفية | Search & Filter
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>البحث | Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="البحث بالاسم أو البريد | Search by name or email"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>الدور | Role</Label>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأدوار | All Roles</SelectItem>
                  <SelectItem value="user">مستخدم | User</SelectItem>
                  <SelectItem value="admin">مدير | Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>الحالة | Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات | All Status</SelectItem>
                  <SelectItem value="active">نشط | Active</SelectItem>
                  <SelectItem value="banned">محظور | Banned</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="invisible">Actions</Label>
              <Button onClick={loadUsers} variant="outline" className="w-full bg-transparent">
                تحديث | Refresh
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>قائمة المستخدمين | Users List</CardTitle>
          <CardDescription>
            إجمالي {users.length} مستخدم، يظهر {filteredUsers.length} | Total {users.length} users, showing{" "}
            {filteredUsers.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الاسم | Name</TableHead>
                    <TableHead>البريد الإلكتروني | Email</TableHead>
                    <TableHead>الدور | Role</TableHead>
                    <TableHead>الحالة | Status</TableHead>
                    <TableHead>تاريخ التسجيل | Join Date</TableHead>
                    <TableHead>آخر دخول | Last Login</TableHead>
                    <TableHead>الإجراءات | Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.uid}>
                      <TableCell className="font-medium">{user.displayName}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                          {user.role === "admin" ? "مدير | Admin" : "مستخدم | User"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.status === "active" ? "default" : "destructive"}>
                          {user.status === "active" ? "نشط | Active" : "محظور | Banned"}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>{formatDate(user.lastLoginAt)}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditUser(user)}>
                              <Edit className="h-4 w-4 mr-2" />
                              تعديل | Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleToggleBan(user)}>
                              {user.status === "active" ? (
                                <>
                                  <Ban className="h-4 w-4 mr-2" />
                                  حظر | Ban
                                </>
                              ) : (
                                <>
                                  <UserCheck className="h-4 w-4 mr-2" />
                                  إلغاء الحظر | Unban
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleDeleteUser(user.uid)} className="text-destructive">
                              <Trash2 className="h-4 w-4 mr-2" />
                              حذف | Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {filteredUsers.length === 0 && !loading && (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">لا توجد مستخدمين | No users found</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل المستخدم | Edit User</DialogTitle>
            <DialogDescription>
              تعديل بيانات المستخدم والصلاحيات | Edit user information and permissions
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>الاسم | Display Name</Label>
              <Input
                value={editForm.displayName}
                onChange={(e) => setEditForm({ ...editForm, displayName: e.target.value })}
                placeholder="أدخل الاسم | Enter display name"
              />
            </div>

            <div className="space-y-2">
              <Label>البريد الإلكتروني | Email</Label>
              <Input
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                placeholder="أدخل البريد الإلكتروني | Enter email"
                disabled
              />
            </div>

            <div className="space-y-2">
              <Label>الدور | Role</Label>
              <Select
                value={editForm.role}
                onValueChange={(value: "user" | "admin") => setEditForm({ ...editForm, role: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">مستخدم | User</SelectItem>
                  <SelectItem value="admin">مدير | Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>الحالة | Status</Label>
              <Select
                value={editForm.status}
                onValueChange={(value: "active" | "banned") => setEditForm({ ...editForm, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">نشط | Active</SelectItem>
                  <SelectItem value="banned">محظور | Banned</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingUser(null)}>
              إلغاء | Cancel
            </Button>
            <Button onClick={handleSaveUser}>حفظ التغييرات | Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
