"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, AlertTriangle, Activity, Eye, RefreshCw } from "lucide-react"
import { collection, query, orderBy, limit, getDocs, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useSecurity } from "@/hooks/use-security"
import { useLanguage } from "@/components/language-provider"

interface SecurityEvent {
  id: string
  userId: string
  userEmail: string
  action: string
  resource: string
  severity: "low" | "medium" | "high" | "critical"
  timestamp: any
  details?: Record<string, any>
}

export function SecurityMonitor() {
  const { t } = useLanguage()
  const { securityAlerts, addSecurityAlert } = useSecurity()
  const [recentEvents, setRecentEvents] = useState<SecurityEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [criticalAlerts, setCriticalAlerts] = useState(0)

  const loadSecurityEvents = async () => {
    try {
      setLoading(true)

      // Load recent audit logs
      const auditQuery = query(collection(db, "audit-logs"), orderBy("timestamp", "desc"), limit(20))

      const snapshot = await getDocs(auditQuery)
      const events = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as SecurityEvent[]

      setRecentEvents(events)

      // Count critical alerts from last 24 hours
      const yesterday = new Date()
      yesterday.setDate(yesterday.getDate() - 1)

      const criticalQuery = query(
        collection(db, "audit-logs"),
        where("severity", "==", "critical"),
        where("timestamp", ">=", yesterday),
      )

      const criticalSnapshot = await getDocs(criticalQuery)
      setCriticalAlerts(criticalSnapshot.size)
    } catch (error) {
      console.error("Error loading security events:", error)
      addSecurityAlert("Failed to load security events")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadSecurityEvents()

    // Refresh every 30 seconds
    const interval = setInterval(loadSecurityEvents, 30000)
    return () => clearInterval(interval)
  }, [])

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "destructive"
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      case "low":
        return "outline"
      default:
        return "outline"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertTriangle className="h-4 w-4" />
      case "high":
        return <AlertTriangle className="h-4 w-4" />
      case "medium":
        return <Activity className="h-4 w-4" />
      case "low":
        return <Eye className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  const formatTimestamp = (timestamp: any) => {
    if (!timestamp) return "غير محدد | N/A"
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp)
    return date.toLocaleString("ar-EG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      {/* Security Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                <Shield className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-sm font-medium">حالة الأمان | Security Status</p>
                <p className="text-lg font-bold text-green-600">آمن | Secure</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <p className="text-sm font-medium">تنبيهات حرجة | Critical Alerts</p>
                <p className="text-lg font-bold text-orange-600">{criticalAlerts}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm font-medium">الأحداث الأخيرة | Recent Events</p>
                <p className="text-lg font-bold text-blue-600">{recentEvents.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Critical Alerts */}
      {criticalAlerts > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            تم اكتشاف {criticalAlerts} تنبيه أمني حرج خلال الـ 24 ساعة الماضية | {criticalAlerts} critical security
            alerts detected in the last 24 hours
          </AlertDescription>
        </Alert>
      )}

      {/* Live Security Alerts */}
      {securityAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              تنبيهات مباشرة | Live Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {securityAlerts.slice(-5).map((alert, index) => (
                <div
                  key={index}
                  className="text-sm p-2 bg-orange-50 dark:bg-orange-950 rounded border-l-4 border-orange-500"
                >
                  {alert}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Security Events */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            سجل الأحداث الأمنية | Security Event Log
          </CardTitle>
          <Button variant="outline" size="sm" onClick={loadSecurityEvents} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            تحديث | Refresh
          </Button>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">جاري التحميل | Loading...</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {recentEvents.map((event) => (
                <div key={event.id} className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="flex-shrink-0">{getSeverityIcon(event.severity)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={getSeverityColor(event.severity) as any} className="text-xs">
                        {event.severity}
                      </Badge>
                      <span className="text-sm font-medium">{event.action}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {event.userEmail} • {event.resource}
                      {event.resourceId && ` • ${event.resourceId}`}
                    </p>
                    {event.details && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {JSON.stringify(event.details, null, 2).slice(0, 100)}...
                      </p>
                    )}
                  </div>
                  <div className="flex-shrink-0 text-xs text-muted-foreground">{formatTimestamp(event.timestamp)}</div>
                </div>
              ))}

              {recentEvents.length === 0 && (
                <div className="text-center py-8">
                  <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">لا توجد أحداث أمنية | No security events found</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
