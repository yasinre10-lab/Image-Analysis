"use client"

import { useLanguage } from "@/components/language-provider"
import { LanguageToggle } from "@/components/language-toggle"
import { ThemeToggle } from "@/components/theme-toggle"
import { UserMenu } from "@/components/user-menu"
import { DrawingCanvas } from "@/components/drawing-canvas"
import { Palette, ArrowLeft } from "lucide-react"
import Link from "next/link"

export function CanvasPage() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
              <ArrowLeft className="h-4 w-4" />
              الرئيسية | Home
            </Link>

            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              <span className="font-semibold text-sm">لوحة الرسم | Canvas</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <LanguageToggle />
            <ThemeToggle />
            <UserMenu />
          </div>
        </div>
      </header>

      {/* Drawing Canvas */}
      <div className="flex-1 relative">
        <DrawingCanvas />
      </div>
    </div>
  )
}
