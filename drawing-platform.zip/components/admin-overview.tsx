"use client"

import { useState, useEffect } from "react"
import { useLanguage } from "@/components/language-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  ImageIcon,
  Palette,
  Activity,
  TrendingUp,
  Shield,
  Calendar,
  Download,
  Eye,
  Heart,
  Share,
  Clock,
  BarChart3,
  PieChart,
  LineChart,
} from "lucide-react"
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Area,
  AreaChart,
} from "recharts"
import { collection, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

interface DashboardStats {
  totalUsers: number
  activeUsers: number
  newUsersToday: number
  totalArtworks: number
  featuredArtworks: number
  artworksToday: number
  totalViews: number
  totalLikes: number
  totalShares: number
  totalDownloads: number
  averageSessionTime: number
  topTools: Array<{ name: string; usage: number }>
  topColors: Array<{ color: string; usage: number }>
  userGrowth: Array<{ date: string; users: number }>
  artworkGrowth: Array<{ date: string; artworks: number }>
  activityData: Array<{ hour: number; activity: number }>
  deviceStats: Array<{ device: string; count: number }>
}

export function AdminOverview() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "90d" | "1y">("30d")
  const [refreshing, setRefreshing] = useState(false)

  // Load dashboard statistics
  const loadStats = async () => {
    try {
      setLoading(true)

      // Get users data
      const usersSnapshot = await getDocs(collection(db, "users"))
      const users = usersSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))

      // Get artworks data
      const artworksSnapshot = await getDocs(collection(db, "artworks"))
      const artworks = artworksSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))

      // Calculate statistics
      const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

      const newUsersToday = users.filter((user) => {
        const createdAt = user.createdAt?.toDate?.() || new Date(user.createdAt)
        return createdAt >= today
      }).length

      const artworksToday = artworks.filter((artwork) => {
        const createdAt = artwork.createdAt?.toDate?.() || new Date(artwork.createdAt)
        return createdAt >= today
      }).length

      const featuredArtworks = artworks.filter((artwork) => artwork.featured).length
      const totalViews = artworks.reduce((sum, artwork) => sum + (artwork.views || 0), 0)
      const totalLikes = artworks.reduce((sum, artwork) => sum + (artwork.likes || 0), 0)

      // Generate mock data for charts (in real app, this would come from analytics)
      const userGrowth = generateTimeSeriesData(timeRange, "users")
      const artworkGrowth = generateTimeSeriesData(timeRange, "artworks")
      const activityData = generateHourlyActivity()
      const topTools = generateTopTools()
      const topColors = generateTopColors()
      const deviceStats = generateDeviceStats()

      const dashboardStats: DashboardStats = {
        totalUsers: users.length,
        activeUsers: Math.floor(users.length * 0.7), // Mock: 70% active
        newUsersToday,
        totalArtworks: artworks.length,
        featuredArtworks,
        artworksToday,
        totalViews,
        totalLikes,
        totalShares: Math.floor(totalViews * 0.1), // Mock: 10% share rate
        totalDownloads: Math.floor(totalViews * 0.05), // Mock: 5% download rate
        averageSessionTime: 25, // Mock: 25 minutes
        topTools,
        topColors,
        userGrowth,
        artworkGrowth,
        activityData,
        deviceStats,
      }

      setStats(dashboardStats)
    } catch (error) {
      console.error("Error loading dashboard stats:", error)
      toast({
        title: "خطأ | Error",
        description: "فشل في تحميل الإحصائيات | Failed to load statistics",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  // Generate mock time series data
  const generateTimeSeriesData = (range: string, type: "users" | "artworks") => {
    const days = range === "7d" ? 7 : range === "30d" ? 30 : range === "90d" ? 90 : 365
    const data = []
    const baseValue = type === "users" ? 50 : 20

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const value = baseValue + Math.floor(Math.random() * 30) + (days - i) * 2
      data.push({
        date: date.toLocaleDateString("ar-EG", { month: "short", day: "numeric" }),
        [type]: value,
      })
    }
    return data
  }

  // Generate mock hourly activity data
  const generateHourlyActivity = () => {
    const data = []
    for (let hour = 0; hour < 24; hour++) {
      const activity = Math.floor(Math.random() * 100) + 20
      data.push({ hour, activity })
    }
    return data
  }

  // Generate mock top tools data
  const generateTopTools = () => [
    { name: "فرشاة | Brush", usage: 45 },
    { name: "قلم رصاص | Pencil", usage: 32 },
    { name: "ممحاة | Eraser", usage: 28 },
    { name: "دائرة | Circle", usage: 22 },
    { name: "مستطيل | Rectangle", usage: 18 },
  ]

  // Generate mock top colors data
  const generateTopColors = () => [
    { color: "#000000", usage: 35 },
    { color: "#ffffff", usage: 28 },
    { color: "#ff0000", usage: 22 },
    { color: "#0000ff", usage: 18 },
    { color: "#00ff00", usage: 15 },
  ]

  // Generate mock device stats
  const generateDeviceStats = () => [
    { device: "سطح المكتب | Desktop", count: 60 },
    { device: "الهاتف | Mobile", count: 35 },
    { device: "الجهاز اللوحي | Tablet", count: 5 },
  ]

  const refreshStats = async () => {
    setRefreshing(true)
    await loadStats()
  }

  useEffect(() => {
    loadStats()
  }, [timeRange])

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="mt-2 text-muted-foreground">جاري تحميل الإحصائيات | Loading statistics...</p>
      </div>
    )
  }

  if (!stats) return null

  const mainStats = [
    {
      title: "إجمالي المستخدمين | Total Users",
      value: stats.totalUsers.toLocaleString(),
      change: `+${stats.newUsersToday}`,
      changeLabel: "اليوم | today",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "الأعمال الفنية | Artworks",
      value: stats.totalArtworks.toLocaleString(),
      change: `+${stats.artworksToday}`,
      changeLabel: "اليوم | today",
      icon: ImageIcon,
      color: "text-green-600",
    },
    {
      title: "المستخدمون النشطون | Active Users",
      value: stats.activeUsers.toLocaleString(),
      change: `${Math.round((stats.activeUsers / stats.totalUsers) * 100)}%`,
      changeLabel: "من الإجمالي | of total",
      icon: Activity,
      color: "text-orange-600",
    },
    {
      title: "إجمالي المشاهدات | Total Views",
      value: stats.totalViews.toLocaleString(),
      change: `${stats.featuredArtworks}`,
      changeLabel: "مبرز | featured",
      icon: Eye,
      color: "text-purple-600",
    },
  ]

  const engagementStats = [
    { title: "الإعجابات | Likes", value: stats.totalLikes, icon: Heart, color: "text-red-500" },
    { title: "المشاركات | Shares", value: stats.totalShares, icon: Share, color: "text-blue-500" },
    { title: "التحميلات | Downloads", value: stats.totalDownloads, icon: Download, color: "text-green-500" },
    {
      title: "متوسط الجلسة | Avg Session",
      value: `${stats.averageSessionTime}m`,
      icon: Clock,
      color: "text-yellow-500",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">لوحة الإحصائيات | Statistics Dashboard</h1>
          <p className="text-muted-foreground mt-2">تحليلات شاملة لأداء المنصة | Comprehensive platform analytics</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">7 أيام | 7 days</SelectItem>
              <SelectItem value="30d">30 يوم | 30 days</SelectItem>
              <SelectItem value="90d">90 يوم | 90 days</SelectItem>
              <SelectItem value="1y">سنة | 1 year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={refreshStats} disabled={refreshing}>
            <TrendingUp className="h-4 w-4 mr-2" />
            {refreshing ? "تحديث | Refreshing..." : "تحديث | Refresh"}
          </Button>
          <Badge variant="secondary" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            وضع الإدارة | Admin Mode
          </Badge>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {mainStats.map((stat, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <TrendingUp className="h-3 w-3" />
                <span>
                  {stat.change} {stat.changeLabel}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Engagement Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {engagementStats.map((stat, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg bg-background ${stat.color}`}>
                <stat.icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-sm font-medium">{stat.title}</p>
                <p className="text-lg font-bold">
                  {typeof stat.value === "number" ? stat.value.toLocaleString() : stat.value}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="growth" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="growth">النمو | Growth</TabsTrigger>
          <TabsTrigger value="activity">النشاط | Activity</TabsTrigger>
          <TabsTrigger value="tools">الأدوات | Tools</TabsTrigger>
          <TabsTrigger value="devices">الأجهزة | Devices</TabsTrigger>
        </TabsList>

        {/* Growth Charts */}
        <TabsContent value="growth" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="h-5 w-5" />
                  نمو المستخدمين | User Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsLineChart data={stats.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="users" stroke="#8884d8" strokeWidth={2} />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  نمو الأعمال الفنية | Artwork Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={stats.artworkGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="artworks" stroke="#82ca9d" fill="#82ca9d" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Activity Charts */}
        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                النشاط اليومي | Daily Activity
              </CardTitle>
              <CardDescription>النشاط حسب الساعة خلال اليوم | Activity by hour throughout the day</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RechartsBarChart data={stats.activityData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="activity" fill="#8884d8" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tools Usage */}
        <TabsContent value="tools" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  الأدوات الأكثر استخداماً | Most Used Tools
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart data={stats.topTools} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Bar dataKey="usage" fill="#8884d8" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>الألوان الأكثر استخداماً | Most Used Colors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.topColors.map((colorData, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div
                        className="w-6 h-6 rounded border-2 border-border"
                        style={{ backgroundColor: colorData.color }}
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{colorData.color}</span>
                          <span className="text-sm text-muted-foreground">{colorData.usage}%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2 mt-1">
                          <div
                            className="bg-primary h-2 rounded-full transition-all duration-300"
                            style={{ width: `${colorData.usage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Device Stats */}
        <TabsContent value="devices" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  إحصائيات الأجهزة | Device Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={stats.deviceStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ device, percent }) => `${device} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {stats.deviceStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>ملخص الأداء | Performance Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-accent rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {((stats.activeUsers / stats.totalUsers) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">معدل النشاط | Activity Rate</div>
                  </div>
                  <div className="text-center p-4 bg-accent rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {(stats.totalViews / stats.totalArtworks).toFixed(1)}
                    </div>
                    <div className="text-sm text-muted-foreground">متوسط المشاهدات | Avg Views</div>
                  </div>
                  <div className="text-center p-4 bg-accent rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {((stats.featuredArtworks / stats.totalArtworks) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">معدل الإبراز | Featured Rate</div>
                  </div>
                  <div className="text-center p-4 bg-accent rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {((stats.totalLikes / stats.totalViews) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">معدل الإعجاب | Like Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            النشاط الأخير | Recent Activity
          </CardTitle>
          <CardDescription>آخر الأنشطة في النظام | Latest system activities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>مستخدم جديد انضم | New user joined</span>
              <span className="text-muted-foreground text-xs">منذ 5 دقائق | 5 min ago</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>عمل فني جديد تم رفعه | New artwork uploaded</span>
              <span className="text-muted-foreground text-xs">منذ 12 دقيقة | 12 min ago</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span>تم تحديث الإعدادات | Settings updated</span>
              <span className="text-muted-foreground text-xs">منذ ساعة | 1 hour ago</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>تم إبراز عمل فني | Artwork featured</span>
              <span className="text-muted-foreground text-xs">منذ ساعتين | 2 hours ago</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <span>تم حذف محتوى مخالف | Inappropriate content removed</span>
              <span className="text-muted-foreground text-xs">منذ 3 ساعات | 3 hours ago</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
