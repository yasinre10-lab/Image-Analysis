"use client"

import type React from "react"

import { useRef, useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { ColorPicker } from "@/components/color-picker"
import { LayerPanel } from "@/components/layer-panel"
import { useLanguage } from "@/components/language-provider"
import { useAuth } from "@/components/auth-provider"
import { useMobile } from "@/hooks/use-mobile"
import { Brush, Eraser, Undo2, Redo2, ZoomIn, ZoomOut, Save, Layers } from "lucide-react"
import { cn } from "@/lib/utils"

interface DrawingTool {
  type: "brush" | "eraser"
  size: number
  color: string
  opacity: number
}

interface Layer {
  id: string
  name: string
  visible: boolean
  opacity: number
  canvas: HTMLCanvasElement
}

interface DrawingState {
  tool: DrawingTool
  zoom: number
  panX: number
  panY: number
  layers: Layer[]
  activeLayerId: string
  history: ImageData[]
  historyIndex: number
}

export function DrawingCanvas() {
  const { t } = useLanguage()
  const { user } = useAuth()
  const isMobile = useMobile()

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const [isDrawing, setIsDrawing] = useState(false)
  const [showColorPicker, setShowColorPicker] = useState(false)
  const [showLayers, setShowLayers] = useState(false)

  const [drawingState, setDrawingState] = useState<DrawingState>({
    tool: {
      type: "brush",
      size: 5,
      color: "#000000",
      opacity: 1,
    },
    zoom: 1,
    panX: 0,
    panY: 0,
    layers: [
      {
        id: "layer-1",
        name: "Layer 1",
        visible: true,
        opacity: 1,
        canvas: document.createElement("canvas"),
      },
    ],
    activeLayerId: "layer-1",
    history: [],
    historyIndex: -1,
  })

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const resizeCanvas = () => {
      const rect = container.getBoundingClientRect()
      canvas.width = rect.width
      canvas.height = rect.height

      // Redraw all layers
      redrawCanvas()
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    return () => window.removeEventListener("resize", resizeCanvas)
  }, [])

  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Apply zoom and pan
    ctx.save()
    ctx.scale(drawingState.zoom, drawingState.zoom)
    ctx.translate(drawingState.panX, drawingState.panY)

    // Draw all visible layers
    drawingState.layers.forEach((layer) => {
      if (layer.visible) {
        ctx.globalAlpha = layer.opacity
        ctx.drawImage(layer.canvas, 0, 0)
      }
    })

    ctx.restore()
  }, [drawingState.layers, drawingState.zoom, drawingState.panX, drawingState.panY])

  const getActiveLayer = useCallback(() => {
    return drawingState.layers.find((layer) => layer.id === drawingState.activeLayerId)
  }, [drawingState.layers, drawingState.activeLayerId])

  const saveToHistory = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    const newHistory = drawingState.history.slice(0, drawingState.historyIndex + 1)
    newHistory.push(imageData)

    setDrawingState((prev) => ({
      ...prev,
      history: newHistory.slice(-50), // Keep last 50 states
      historyIndex: Math.min(newHistory.length - 1, 49),
    }))
  }, [drawingState.history, drawingState.historyIndex])

  const getEventPos = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      const canvas = canvasRef.current
      if (!canvas) return { x: 0, y: 0 }

      const rect = canvas.getBoundingClientRect()
      let clientX: number, clientY: number

      if ("touches" in e) {
        clientX = e.touches[0]?.clientX || 0
        clientY = e.touches[0]?.clientY || 0
      } else {
        clientX = e.clientX
        clientY = e.clientY
      }

      return {
        x: (clientX - rect.left - drawingState.panX) / drawingState.zoom,
        y: (clientY - rect.top - drawingState.panY) / drawingState.zoom,
      }
    },
    [drawingState.zoom, drawingState.panX, drawingState.panY],
  )

  const startDrawing = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      e.preventDefault()
      const activeLayer = getActiveLayer()
      if (!activeLayer) return

      setIsDrawing(true)
      saveToHistory()

      const pos = getEventPos(e)
      const ctx = activeLayer.canvas.getContext("2d")
      if (!ctx) return

      ctx.beginPath()
      ctx.moveTo(pos.x, pos.y)

      // Set drawing properties
      ctx.lineWidth = drawingState.tool.size
      ctx.lineCap = "round"
      ctx.lineJoin = "round"

      if (drawingState.tool.type === "brush") {
        ctx.globalCompositeOperation = "source-over"
        ctx.strokeStyle = drawingState.tool.color
        ctx.globalAlpha = drawingState.tool.opacity
      } else {
        ctx.globalCompositeOperation = "destination-out"
        ctx.globalAlpha = 1
      }
    },
    [drawingState.tool, getActiveLayer, getEventPos, saveToHistory],
  )

  const draw = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (!isDrawing) return
      e.preventDefault()

      const activeLayer = getActiveLayer()
      if (!activeLayer) return

      const pos = getEventPos(e)
      const ctx = activeLayer.canvas.getContext("2d")
      if (!ctx) return

      ctx.lineTo(pos.x, pos.y)
      ctx.stroke()

      redrawCanvas()
    },
    [isDrawing, getActiveLayer, getEventPos, redrawCanvas],
  )

  const stopDrawing = useCallback(() => {
    setIsDrawing(false)
  }, [])

  const undo = useCallback(() => {
    if (drawingState.historyIndex > 0) {
      setDrawingState((prev) => ({
        ...prev,
        historyIndex: prev.historyIndex - 1,
      }))

      const canvas = canvasRef.current
      if (!canvas) return

      const ctx = canvas.getContext("2d")
      if (!ctx) return

      const imageData = drawingState.history[drawingState.historyIndex - 1]
      if (imageData) {
        ctx.putImageData(imageData, 0, 0)
      }
    }
  }, [drawingState.history, drawingState.historyIndex])

  const redo = useCallback(() => {
    if (drawingState.historyIndex < drawingState.history.length - 1) {
      setDrawingState((prev) => ({
        ...prev,
        historyIndex: prev.historyIndex + 1,
      }))

      const canvas = canvasRef.current
      if (!canvas) return

      const ctx = canvas.getContext("2d")
      if (!ctx) return

      const imageData = drawingState.history[drawingState.historyIndex + 1]
      if (imageData) {
        ctx.putImageData(imageData, 0, 0)
      }
    }
  }, [drawingState.history, drawingState.historyIndex])

  const zoomIn = useCallback(() => {
    setDrawingState((prev) => ({
      ...prev,
      zoom: Math.min(prev.zoom * 1.2, 5),
    }))
  }, [])

  const zoomOut = useCallback(() => {
    setDrawingState((prev) => ({
      ...prev,
      zoom: Math.max(prev.zoom / 1.2, 0.1),
    }))
  }, [])

  const saveDrawing = useCallback(async () => {
    const canvas = canvasRef.current
    if (!canvas || !user) return

    try {
      const dataURL = canvas.toDataURL("image/png")
      // TODO: Save to Firebase Storage
      console.log("Saving drawing...", dataURL.substring(0, 50))

      // Create download link as fallback
      const link = document.createElement("a")
      link.download = `drawing-${Date.now()}.png`
      link.href = dataURL
      link.click()
    } catch (error) {
      console.error("Error saving drawing:", error)
    }
  }, [user])

  const toolbarItems = [
    {
      icon: Brush,
      label: t("drawing.brush"),
      active: drawingState.tool.type === "brush",
      onClick: () =>
        setDrawingState((prev) => ({
          ...prev,
          tool: { ...prev.tool, type: "brush" },
        })),
    },
    {
      icon: Eraser,
      label: t("drawing.eraser"),
      active: drawingState.tool.type === "eraser",
      onClick: () =>
        setDrawingState((prev) => ({
          ...prev,
          tool: { ...prev.tool, type: "eraser" },
        })),
    },
    {
      icon: Undo2,
      label: t("drawing.undo"),
      onClick: undo,
      disabled: drawingState.historyIndex <= 0,
    },
    {
      icon: Redo2,
      label: t("drawing.redo"),
      onClick: redo,
      disabled: drawingState.historyIndex >= drawingState.history.length - 1,
    },
    {
      icon: ZoomIn,
      label: "تكبير | Zoom In",
      onClick: zoomIn,
    },
    {
      icon: ZoomOut,
      label: "تصغير | Zoom Out",
      onClick: zoomOut,
    },
    {
      icon: Save,
      label: t("drawing.save"),
      onClick: saveDrawing,
    },
  ]

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Canvas Container */}
      <div
        ref={containerRef}
        className="absolute inset-0 canvas-container cursor-crosshair"
        style={{ touchAction: "none" }}
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
      </div>

      {/* Desktop Toolbar - Left Side */}
      {!isMobile && (
        <Card className="absolute left-4 top-4 bottom-4 w-16 p-2 flex flex-col gap-2 bg-background/95 backdrop-blur">
          {toolbarItems.map((item, index) => (
            <Button
              key={index}
              variant={item.active ? "default" : "ghost"}
              size="sm"
              className={cn(
                "w-12 h-12 p-0",
                item.active && "tool-active",
                item.disabled && "opacity-50 cursor-not-allowed",
              )}
              onClick={item.onClick}
              disabled={item.disabled}
              title={item.label}
            >
              <item.icon className="h-5 w-5" />
            </Button>
          ))}

          <div className="border-t pt-2 mt-2">
            <Button
              variant="ghost"
              size="sm"
              className="w-12 h-12 p-0"
              onClick={() => setShowColorPicker(!showColorPicker)}
              title={t("drawing.color")}
            >
              <div
                className="w-6 h-6 rounded border-2 border-background"
                style={{ backgroundColor: drawingState.tool.color }}
              />
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="w-12 h-12 p-0 mt-2"
              onClick={() => setShowLayers(!showLayers)}
              title={t("drawing.layers")}
            >
              <Layers className="h-5 w-5" />
            </Button>
          </div>
        </Card>
      )}

      {/* Mobile Toolbar - Bottom */}
      {isMobile && (
        <Card className="absolute bottom-4 left-4 right-4 p-3 bg-background/95 backdrop-blur">
          <div className="flex items-center justify-between gap-2 mb-3">
            {toolbarItems.slice(0, 4).map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "default" : "ghost"}
                size="sm"
                className={cn(
                  "flex-1 h-10",
                  item.active && "tool-active",
                  item.disabled && "opacity-50 cursor-not-allowed",
                )}
                onClick={item.onClick}
                disabled={item.disabled}
              >
                <item.icon className="h-4 w-4" />
              </Button>
            ))}
          </div>

          <div className="flex items-center justify-between gap-2">
            {toolbarItems.slice(4).map((item, index) => (
              <Button key={index} variant="ghost" size="sm" className="flex-1 h-10" onClick={item.onClick}>
                <item.icon className="h-4 w-4" />
              </Button>
            ))}

            <Button
              variant="ghost"
              size="sm"
              className="flex-1 h-10"
              onClick={() => setShowColorPicker(!showColorPicker)}
            >
              <div
                className="w-4 h-4 rounded border border-background"
                style={{ backgroundColor: drawingState.tool.color }}
              />
            </Button>
          </div>
        </Card>
      )}

      {/* Brush Size Control */}
      <Card
        className={cn(
          "absolute p-4 bg-background/95 backdrop-blur",
          isMobile ? "top-4 left-4 right-4" : "right-4 top-4 w-64",
        )}
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">
              {drawingState.tool.type === "brush" ? t("drawing.brush") : t("drawing.eraser")}
            </span>
            <span className="text-sm text-muted-foreground">{drawingState.tool.size}px</span>
          </div>

          <Slider
            value={[drawingState.tool.size]}
            onValueChange={([size]) =>
              setDrawingState((prev) => ({
                ...prev,
                tool: { ...prev.tool, size },
              }))
            }
            min={1}
            max={50}
            step={1}
            className="w-full"
          />

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">الشفافية | Opacity</span>
            <span className="text-sm text-muted-foreground">{Math.round(drawingState.tool.opacity * 100)}%</span>
          </div>

          <Slider
            value={[drawingState.tool.opacity * 100]}
            onValueChange={([opacity]) =>
              setDrawingState((prev) => ({
                ...prev,
                tool: { ...prev.tool, opacity: opacity / 100 },
              }))
            }
            min={1}
            max={100}
            step={1}
            className="w-full"
          />
        </div>
      </Card>

      {/* Color Picker */}
      {showColorPicker && (
        <div className={cn("absolute z-50", isMobile ? "bottom-32 left-4 right-4" : "left-24 top-4")}>
          <ColorPicker
            color={drawingState.tool.color}
            onChange={(color) =>
              setDrawingState((prev) => ({
                ...prev,
                tool: { ...prev.tool, color },
              }))
            }
            onClose={() => setShowColorPicker(false)}
          />
        </div>
      )}

      {/* Layer Panel */}
      {showLayers && (
        <div className={cn("absolute z-50", isMobile ? "bottom-32 left-4 right-4" : "left-24 top-64")}>
          <LayerPanel
            layers={drawingState.layers}
            activeLayerId={drawingState.activeLayerId}
            onLayerChange={(layers) => setDrawingState((prev) => ({ ...prev, layers }))}
            onActiveLayerChange={(activeLayerId) => setDrawingState((prev) => ({ ...prev, activeLayerId }))}
            onClose={() => setShowLayers(false)}
          />
        </div>
      )}

      {/* Zoom Indicator */}
      <div className="absolute bottom-4 right-4 bg-background/95 backdrop-blur rounded px-3 py-1 text-sm">
        {Math.round(drawingState.zoom * 100)}%
      </div>
    </div>
  )
}
