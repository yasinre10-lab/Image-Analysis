"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import {
  type User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
} from "firebase/auth"
import { doc, setDoc, getDoc } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

interface UserData {
  uid: string
  email: string
  displayName: string
  role: "user" | "admin"
  createdAt: Date
  lastLoginAt: Date
}

interface AuthContextType {
  user: User | null
  userData: UserData | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, displayName: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user)

      if (user) {
        // Fetch additional user data from Firestore
        try {
          const userDoc = await getDoc(doc(db, "users", user.uid))
          if (userDoc.exists()) {
            setUserData(userDoc.data() as UserData)
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
        }
      } else {
        setUserData(null)
      }

      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      setLoading(true)
      if (process.env.NEXT_PUBLIC_FIREBASE_API_KEY === "demo-api-key" || !process.env.NEXT_PUBLIC_FIREBASE_API_KEY) {
        toast({
          title: "وضع العرض التوضيحي | Demo Mode",
          description: "يرجى إعداد Firebase للمصادقة الحقيقية | Please setup Firebase for real authentication",
          variant: "destructive",
        })
        throw new Error("Firebase not configured")
      }

      const result = await signInWithEmailAndPassword(auth, email, password)

      // Update last login time
      await setDoc(
        doc(db, "users", result.user.uid),
        {
          lastLoginAt: new Date(),
        },
        { merge: true },
      )

      toast({
        title: "تم تسجيل الدخول بنجاح | Login Successful",
        description: "مرحباً بك مرة أخرى | Welcome back!",
      })
    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الدخول | Login Error",
        description: error.message,
        variant: "destructive",
      })
      throw error
    } finally {
      setLoading(false)
    }
  }

  const register = async (email: string, password: string, displayName: string) => {
    try {
      setLoading(true)
      if (process.env.NEXT_PUBLIC_FIREBASE_API_KEY === "demo-api-key" || !process.env.NEXT_PUBLIC_FIREBASE_API_KEY) {
        toast({
          title: "وضع العرض التوضيحي | Demo Mode",
          description: "يرجى إعداد Firebase لإنشاء حسابات حقيقية | Please setup Firebase for real account creation",
          variant: "destructive",
        })
        throw new Error("Firebase not configured")
      }

      const result = await createUserWithEmailAndPassword(auth, email, password)

      // Update user profile
      await updateProfile(result.user, { displayName })

      // Create user document in Firestore
      const newUserData: UserData = {
        uid: result.user.uid,
        email: result.user.email!,
        displayName,
        role: "user",
        createdAt: new Date(),
        lastLoginAt: new Date(),
      }

      await setDoc(doc(db, "users", result.user.uid), newUserData)
      setUserData(newUserData)

      toast({
        title: "تم إنشاء الحساب بنجاح | Account Created",
        description: "مرحباً بك في منصة الرسم | Welcome to the Drawing Platform!",
      })
    } catch (error: any) {
      toast({
        title: "خطأ في إنشاء الحساب | Registration Error",
        description: error.message,
        variant: "destructive",
      })
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try {
      await signOut(auth)
      setUserData(null)
      toast({
        title: "تم تسجيل الخروج | Logged Out",
        description: "نراك قريباً | See you soon!",
      })
    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الخروج | Logout Error",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const value = {
    user,
    userData,
    loading,
    login,
    register,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
