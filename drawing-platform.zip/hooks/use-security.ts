"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { auditLogger } from "@/lib/audit-logger"
import { createRateLimiter } from "@/lib/validation"
import { useToast } from "@/hooks/use-toast"

// Rate limiters for different actions
const userActionLimiter = createRateLimiter(10, 60000) // 10 actions per minute
const artworkActionLimiter = createRateLimiter(5, 60000) // 5 actions per minute
const settingsActionLimiter = createRateLimiter(3, 60000) // 3 actions per minute

export function useSecurity() {
  const { userData } = useAuth()
  const { toast } = useToast()
  const [securityAlerts, setSecurityAlerts] = useState<string[]>([])

  // Check if user has admin privileges
  const isAdmin = userData?.role === "admin"

  // Log security-sensitive actions
  const logAction = async (action: string, resource: string, resourceId?: string, details?: Record<string, any>) => {
    if (!userData) return

    try {
      await auditLogger.log({
        userId: userData.uid,
        userEmail: userData.email,
        action,
        resource,
        resourceId,
        details,
        severity: resource === "security" ? "critical" : "medium",
      })
    } catch (error) {
      console.error("Failed to log action:", error)
    }
  }

  // Rate limiting wrapper
  const withRateLimit = (action: () => Promise<void>, limiter: (id: string) => boolean, actionType: string) => {
    return async () => {
      if (!userData) {
        toast({
          title: "خطأ أمني | Security Error",
          description: "غير مصرح لك بهذا الإجراء | You are not authorized for this action",
          variant: "destructive",
        })
        return
      }

      if (!limiter(userData.uid)) {
        toast({
          title: "تم تجاوز الحد المسموح | Rate Limit Exceeded",
          description: "يرجى الانتظار قبل المحاولة مرة أخرى | Please wait before trying again",
          variant: "destructive",
        })

        await auditLogger.logSecurityEvent(userData.uid, userData.email, "rate_limit_exceeded", {
          actionType,
          timestamp: new Date().toISOString(),
        })
        return
      }

      await action()
    }
  }

  // Secure user actions
  const secureUserAction = (action: () => Promise<void>) => {
    return withRateLimit(action, userActionLimiter, "user_action")
  }

  // Secure artwork actions
  const secureArtworkAction = (action: () => Promise<void>) => {
    return withRateLimit(action, artworkActionLimiter, "artwork_action")
  }

  // Secure settings actions
  const secureSettingsAction = (action: () => Promise<void>) => {
    return withRateLimit(action, settingsActionLimiter, "settings_action")
  }

  // Validate admin access
  const requireAdmin = (callback: () => void) => {
    if (!isAdmin) {
      toast({
        title: "وصول مرفوض | Access Denied",
        description: "تحتاج صلاحيات إدارية لهذا الإجراء | Admin privileges required for this action",
        variant: "destructive",
      })

      if (userData) {
        auditLogger.logSecurityEvent(userData.uid, userData.email, "unauthorized_admin_access_attempt", {
          timestamp: new Date().toISOString(),
        })
      }
      return
    }
    callback()
  }

  // Monitor for suspicious activity
  useEffect(() => {
    if (!userData) return

    const checkSuspiciousActivity = () => {
      // In a real implementation, this would check for:
      // - Multiple failed login attempts
      // - Unusual access patterns
      // - Rapid successive actions
      // - Access from unusual locations

      // For demo purposes, we'll just clear old alerts
      setSecurityAlerts((prev) => prev.slice(-5)) // Keep only last 5 alerts
    }

    const interval = setInterval(checkSuspiciousActivity, 30000) // Check every 30 seconds
    return () => clearInterval(interval)
  }, [userData])

  // Add security alert
  const addSecurityAlert = (message: string) => {
    setSecurityAlerts((prev) => [...prev, `${new Date().toLocaleTimeString()}: ${message}`])
  }

  // Validate input data
  const validateInput = (data: any, schema: any): { valid: boolean; errors: string[] } => {
    try {
      schema.parse(data)
      return { valid: true, errors: [] }
    } catch (error: any) {
      const errors = error.errors?.map((err: any) => err.message) || ["Validation failed"]
      return { valid: false, errors }
    }
  }

  // Secure file upload
  const secureFileUpload = async (file: File, maxSize = 10): Promise<{ success: boolean; error?: string }> => {
    if (!userData) {
      return { success: false, error: "Authentication required" }
    }

    // Validate file
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg", "image/gif"]
    if (!allowedTypes.includes(file.type)) {
      await logAction("file_upload_rejected", "security", undefined, {
        reason: "invalid_file_type",
        fileType: file.type,
        fileName: file.name,
      })
      return { success: false, error: "Invalid file type" }
    }

    if (file.size > maxSize * 1024 * 1024) {
      await logAction("file_upload_rejected", "security", undefined, {
        reason: "file_too_large",
        fileSize: file.size,
        fileName: file.name,
      })
      return { success: false, error: `File too large (max ${maxSize}MB)` }
    }

    await logAction("file_upload_accepted", "security", undefined, {
      fileType: file.type,
      fileSize: file.size,
      fileName: file.name,
    })

    return { success: true }
  }

  return {
    isAdmin,
    securityAlerts,
    logAction,
    secureUserAction,
    secureArtworkAction,
    secureSettingsAction,
    requireAdmin,
    addSecurityAlert,
    validateInput,
    secureFileUpload,
  }
}
